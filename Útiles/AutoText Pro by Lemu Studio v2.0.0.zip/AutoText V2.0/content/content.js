// AutoText Pro — Content Script v4 (2.0.0)
// Soporte para %clip% : se reemplaza con el contenido del portapapeles

(function () {
  'use strict';

  // Silenciar errores de contexto invalidado al recargar la extensión
  window.addEventListener('unhandledrejection', e => {
    if (e.reason?.message?.includes('Extension context invalidated')) {
      e.preventDefault();
    }
  });

  const SC_PREFIX = 'sc_';
  let shortcuts = [];
  let clipEnabled = true;

  chrome.storage.sync.get(['clipEnabled'], r => {
    if (!chrome.runtime.lastError) clipEnabled = r.clipEnabled !== false;
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.clipEnabled !== undefined) {
      clipEnabled = changes.clipEnabled.newValue !== false;
    }
  });

  function loadShortcuts() {
    chrome.storage.local.get(null, (r) => {
      shortcuts = [];
      Object.keys(r).forEach(key => {
        if (!key.startsWith(SC_PREFIX)) return;
        try {
          const item = JSON.parse(r[key]);
          if (item.shortcut && item.text) shortcuts.push(item);
        } catch (e) {}
      });
      // Ordenar por longitud descendente: shortcuts más largos primero
      // Evita que "asd" solape a "aasd" — el más específico gana siempre
      shortcuts.sort((a, b) => b.shortcut.length - a.shortcut.length);
    });
  }

  loadShortcuts();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') loadShortcuts();
  });

// Regex que detecta [cualquier texto con espacios] como placeholder
  const PLACEHOLDER_RE = /\[[^\]]*\]/;

  async function expandShortcut(el, sc) {
    let expanded = sc.text;

    if (expanded.includes('%clip%') && clipEnabled) {
      try {
        const clip = await navigator.clipboard.readText();
        expanded = expanded.replaceAll('%clip%', clip);
      } catch (e) {
        expanded = expanded.replaceAll('%clip%', '');
      }
    } else if (expanded.includes('%clip%')) {
      expanded = expanded.replaceAll('%clip%', '');
    }

    // Incrementar uses — ignorar si el contexto fue invalidado
    if (chrome.runtime?.id) {
      chrome.runtime.sendMessage({ type: 'INCREMENT_USES', shortcutId: sc.id }).catch(() => {});
    }

    return expanded;
  }

let _jumping   = false;
let _expanding = false;
  function applyPlaceholderJump(el, isContentEditable, val) {
    if (_jumping) return false;
    const match = PLACEHOLDER_RE.exec(val);
    if (!match) return false;
    const start  = match.index;
    const end    = start + match[0].length;
    const newVal = val.slice(0, start) + val.slice(end);
    _jumping = true;
    if (isContentEditable) {
      el.textContent = newVal;
      const range = document.createRange();
      const sel   = window.getSelection();
      const node  = el.firstChild || el;
      range.setStart(node, Math.min(start, newVal.length));
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    } else {
      const setter = Object.getOwnPropertyDescriptor(
        el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
        'value'
      )?.set;
      if (setter) setter.call(el, newVal);
      else el.value = newVal;
      el.setSelectionRange(start, start);
      el.focus();
    }
    setTimeout(() => { _jumping = false; }, 120);
    return true;
  }
  
  function jumpToFirstPlaceholder(el, isContentEditable) {
    if (_jumping) return false;
    if (isContentEditable) {
      // Usar TreeWalker para no aplanar el DOM
      _jumping = true;
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = walker.nextNode())) {
        const match = PLACEHOLDER_RE.exec(n.textContent);
        if (!match) continue;
        const r = document.createRange();
        r.setStart(n, match.index);
        r.setEnd(n, match.index + match[0].length);
        r.deleteContents();
        const cursor = document.createRange();
        cursor.setStart(n, match.index);
        cursor.collapse(true);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(cursor);
        setTimeout(() => { _jumping = false; }, 120);
        return true;
      }
      _jumping = false;
      return false;
    }
    const val = el.value;
    return applyPlaceholderJump(el, isContentEditable, val);
  }

  // Tab para saltar al siguiente placeholder
  function handleTab(e) {
    if (e.key !== 'Tab') return;
    const el = e.target;
    const isContentEditable = el.isContentEditable;
    const isInput = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
    if (!isInput && !isContentEditable) return;

    const val = isContentEditable ? el.textContent : el.value;
    if (!PLACEHOLDER_RE.test(val)) return;

    e.preventDefault();
    e.stopPropagation();
    jumpToFirstPlaceholder(el, isContentEditable);
  }

  document.addEventListener('keydown', handleTab, true);

  function replaceInInput(el, sc, expanded) {
    const pos    = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
    const val    = el.value;
    const start  = pos - sc.shortcut.length;
    if (start < 0) return;

    const safeExpanded = el.tagName === 'INPUT'
      ? expanded.replace(/\n+/g, ' ')
      : expanded;

    const newVal = val.substring(0, start) + safeExpanded + val.substring(pos);
    const proto  = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, newVal);
    else el.value = newVal;

    el.dispatchEvent(new Event('change', { bubbles: true }));

    // Saltar al primer placeholder si existe, si no posicionar cursor
    if (PLACEHOLDER_RE.test(newVal)) {
      applyPlaceholderJump(el, false, newVal);
    } else {
      el.setSelectionRange(start + safeExpanded.length, start + safeExpanded.length);
    }
  }

  function replaceInContentEditable(el, sc, expanded) {
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount) return;
    const range = sel.getRangeAt(0);
    const node  = range.startContainer;
    if (node.nodeType !== Node.TEXT_NODE) return;

    const text   = node.textContent;
    const offset = range.startOffset;
    const before = text.substring(0, offset);
    if (!before.endsWith(sc.shortcut)) return;

    // Borrar el shortcut del nodo exacto
    const range2 = document.createRange();
    range2.setStart(node, before.length - sc.shortcut.length);
    range2.setEnd(node, offset);
    range2.deleteContents();

    // Insertar fragmento respetando saltos de línea
    const lines = expanded.split('\n');
    const frag  = document.createDocumentFragment();
    let lastTextNode;
    lines.forEach((line, i) => {
      if (i > 0) frag.appendChild(document.createElement('br'));
      const tn = document.createTextNode(line);
      frag.appendChild(tn);
      lastTextNode = tn;
    });
    range2.insertNode(frag);

    // Posicionar cursor al final del último nodo insertado
    const newRange = document.createRange();
    newRange.setStart(lastTextNode, lastTextNode.length);
    newRange.collapse(true);
    sel.removeAllRanges();
    sel.addRange(newRange);

    // Saltar al primer placeholder usando Range para no aplanar el DOM
    if (PLACEHOLDER_RE.test(expanded)) {
      setTimeout(() => {
        const s2 = window.getSelection();
        if (!s2) return;
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = walker.nextNode())) {
          const match = PLACEHOLDER_RE.exec(n.textContent);
          if (!match) continue;
          // Borrar solo el match dentro del nodo usando deleteContents
          const r = document.createRange();
          r.setStart(n, match.index);
          r.setEnd(n, match.index + match[0].length);
          r.deleteContents();
          const cursor = document.createRange();
          cursor.setStart(n, match.index);
          cursor.collapse(true);
          s2.removeAllRanges();
          s2.addRange(cursor);
          break;
        }
      }, 30);
    }
  }

  async function handleInput(e) {
    if (_expanding) return;
    const el = e.target;
    const isContentEditable = el.isContentEditable;
    const isInput = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
    if (!isInput && !isContentEditable) return;

    // Leer texto antes del cursor
    let before = '';
    if (isInput) {
      const pos = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
      before = el.value.substring(0, pos);
    } else {
      const sel = window.getSelection();
      if (!sel || !sel.rangeCount) return;
      const range = sel.getRangeAt(0);
      const node  = range.startContainer;
      if (node.nodeType !== Node.TEXT_NODE) return;
      before = node.textContent.substring(0, range.startOffset);
    }

    if (!before) return;

    for (const sc of shortcuts) {
      if (!sc.shortcut || !sc.text) continue;
      if (!before.endsWith(sc.shortcut)) continue;

      // Validar que el carácter antes del shortcut sea espacio, salto, tab o inicio
      const charBefore = before[before.length - sc.shortcut.length - 1];
      if (charBefore !== undefined && charBefore !== ' ' && charBefore !== '\n' && charBefore !== '\t') continue;

      _expanding = true;
      const expanded = await expandShortcut(el, sc);
      if (isInput) replaceInInput(el, sc, expanded);
      else replaceInContentEditable(el, sc, expanded);
      setTimeout(() => { _expanding = false; }, 150);
      return;
    }
  }

  document.addEventListener('input', handleInput, true);
})();
