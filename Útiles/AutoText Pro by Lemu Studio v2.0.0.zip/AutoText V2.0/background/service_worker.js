// AutoText Pro — Service Worker v4 (2.0.0)

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    const id1 = String(Date.now());
    const id2 = String(Date.now() + 1);
    const examples = {
      ['sc_' + id1]: JSON.stringify({ id: id1, shortcut: '.hola', text: '¡Hola! ¿Cómo estás? Espero que tengas un excelente día.', category: 'General', uses: 0 }),
      ['sc_' + id2]: JSON.stringify({ id: id2, shortcut: '*tel', text: '3001234567', category: 'General', uses: 0 }),
    };
    // v2.0: shortcuts van a local, no a sync
    chrome.storage.local.set(examples);
  }

  // Badge rojo "!" en el ícono al actualizar desde versión menor a 2.0.0
  if (details.reason === 'update' && details.previousVersion) {
    const prevMajorMinor = parseFloat(details.previousVersion);
    if (prevMajorMinor < 2.0) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#e53e3e' });
    }
  }

  // Badge rojo "!" en el ícono al actualizar desde versión menor a 2.0.0
  if (details.reason === 'update' && details.previousVersion) {
    const prevMajorMinor = parseFloat(details.previousVersion);
    if (prevMajorMinor < 2.0) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#e53e3e' });
    }
  }

  // Inject content script into all open tabs
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) continue;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ['content/content.js'],
      });
    } catch (_) {}
  }
});

// Increment uses counter from content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== 'INCREMENT_USES' || !msg.shortcutId) return;
  const key = 'sc_' + msg.shortcutId;
  chrome.storage.local.get(key, (r) => {
    if (!r[key]) return;
    try {
      const item = JSON.parse(r[key]);
      item.uses = (item.uses || 0) + 1;
      chrome.storage.local.set({ [key]: JSON.stringify(item) });
    } catch (e) {}
  });
});

// Open options page when toolbar icon is clicked, clearing the update badge
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
  chrome.action.setBadgeText({ text: '' });
});

// Open options page with keyboard shortcut Alt+Shift+A
chrome.commands.onCommand.addListener((command) => {
  if (command === 'open-options') {
    chrome.runtime.openOptionsPage();
  }
});
