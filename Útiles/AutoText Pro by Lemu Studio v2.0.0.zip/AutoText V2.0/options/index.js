// AutoText Pro — Options Page JS v4 (2.0.0)
// Storage: chrome.storage.local para shortcuts, chrome.storage.sync para preferencias
// Drive: backup automático + manual con chrome.identity
'use strict';

const PAGE_SIZE = 25;
let allShortcuts   = [];
let filtered       = [];
let currentPage    = 1;
let searchQuery    = '';
let editingId      = null;
let deleteId       = null;
let activeCategory = 'all';
let allCategories  = [{ name: 'General', desc: '' }];
let clipEnabled    = true;

// ── Paleta de colores para categorías (determinista por nombre) ───────────────
const CAT_COLORS = [
  '#e53e3e','#dd6b20','#d69e2e','#38a169','#319795',
  '#3182ce','#805ad5','#d53f8c','#2b6cb0',
  '#276749','#744210','#553c9a','#97266d','#2c7a7b'
];
function catColor(name) {
  if (!name || name === 'General') return 'var(--primary)';
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffff;
  return CAT_COLORS[h % CAT_COLORS.length];
}

// ── DOM ───────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

const searchInput      = $('searchInput');
const btnClearSearch   = $('btnClearSearch');
const btnNew           = $('btnNew');
const btnExport        = $('btnExport');
const btnImport        = $('btnImport');
const fileInput        = $('fileInput');
const listEl           = $('shortcutsList');
const emptyState       = $('emptyState');
const paginationEl     = $('pagination');
const statsTotal       = $('statsTotal');
const statsFiltered    = $('statsFiltered');

const modalOverlay     = $('modalOverlay');
const modalTitle       = $('modalTitle');
const inputShortcut    = $('inputShortcut');
const inputText        = $('inputText');
const charCount        = $('charCount');
const btnSaveModal     = $('btnSaveModal');
const btnCancelModal   = $('btnCancelModal');
const btnCloseModal    = $('btnCloseModal');

const deleteOverlay    = $('deleteOverlay');
const deleteShortcutName = $('deleteShortcutName');
const btnConfirmDelete = $('btnConfirmDelete');
const btnCancelDelete  = $('btnCancelDelete');
const btnCloseDelete   = $('btnCloseDelete');

const testArea         = $('testArea');
const btnClearTest     = $('btnClearTest');
const hintList         = $('hintList');
const toast            = $('toast');

// ── Idioma (i18n) ─────────────────────────────────────────────────────────────
const langSelectTrigger  = $('langSelectTrigger');
const langSelectDropdown = $('langSelectDropdown');
const langSelectBox      = $('langSelect');
const langSelectLabel    = $('langSelectLabel');

langSelectTrigger.addEventListener('click', (e) => {
  e.stopPropagation();
  langSelectBox.classList.toggle('open');
});

langSelectDropdown.querySelectorAll('.custom-select-option').forEach(opt => {
  opt.addEventListener('click', (e) => {
    e.stopPropagation();
    i18n.setLanguage(opt.dataset.lang, () => {
      applyTranslations();
      applyFilter();
      renderDriveStatus();
    });
    langSelectBox.classList.remove('open');
  });
});

document.addEventListener('click', () => {
  langSelectBox.classList.remove('open');
});

function applyTranslations() {
  if (langSelectLabel) langSelectLabel.textContent = i18n.current.toUpperCase();
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.innerHTML = i18n.t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = i18n.t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = i18n.t(el.dataset.i18nTitle);
  });
}

// ── Storage: local para shortcuts, sync para prefs ────────────────────────────
const SC_PREFIX = 'sc_';
function keyFor(id) { return SC_PREFIX + id; }

function loadFromLocal(cb) {
  chrome.storage.local.get(null, (r) => {
    allShortcuts = [];
    Object.keys(r).forEach(key => {
      if (!key.startsWith(SC_PREFIX)) return;
      try {
        const item = JSON.parse(r[key]);
        allShortcuts.push(item);
      } catch (e) {}
    });

    // Migración automática desde sync (usuarios de v1.x)
    if (!allShortcuts.length) {
      chrome.storage.sync.get(null, (sr) => {
        if (sr.categories && sr.categories.length) allCategories = sr.categories;
        const legacyKeys = Object.keys(sr).filter(k => k.startsWith(SC_PREFIX));
        if (legacyKeys.length) {
          const migrated = {};
          legacyKeys.forEach(k => { migrated[k] = sr[k]; });
          allShortcuts = legacyKeys.map(k => {
            try { return JSON.parse(sr[k]); } catch(e) { return null; }
          }).filter(Boolean);
          chrome.storage.local.set(migrated, () => {
            chrome.storage.sync.remove(legacyKeys);
            showToast(i18n.t('toastMigrated', { count: allShortcuts.length }));
            lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
            applyFilter();
            if (cb) cb();
          });
          return;
        }

        // Formato legacy viejo (shortcuts / shortcuts_N)
        let legacy = [];
        let i = 0;
        while (sr['shortcuts_' + i]) { legacy = legacy.concat(sr['shortcuts_' + i]); i++; }
        if (i === 0 && Array.isArray(sr.shortcuts)) legacy = sr.shortcuts;
        if (legacy.length) {
          allShortcuts = legacy.map(item => Array.isArray(item)
            ? { shortcut: item[0], text: item[1], category: item[2] || 'General', id: item[3] || String(Date.now() + Math.random()), uses: item[4] || 0 }
            : item
          );
          const dataToSave = {};
          allShortcuts.forEach(sc => { dataToSave[keyFor(sc.id)] = JSON.stringify(sc); });
          chrome.storage.local.set(dataToSave, () => {
            chrome.storage.sync.remove(['shortcuts', ...Array.from({length: i}, (_, idx) => 'shortcuts_' + idx)]);
            lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
            applyFilter();
            if (cb) cb();
          });
          return;
        }

        lastKnownIds = new Set();
        applyFilter();
        if (cb) cb();
      });
      return;
    }

    // Cargar categorías desde sync
    chrome.storage.sync.get('categories', (sr) => {
      if (sr.categories && sr.categories.length) allCategories = sr.categories;
      lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
      applyFilter();
      if (cb) cb();
    });
  });
}

// ── Init ──────────────────────────────────────────────────────────────────────
$('footerYear').textContent = new Date().getFullYear();
$('footerVersion').textContent = chrome.runtime.getManifest().version;

i18n.init(() => {
  applyTranslations();
  chrome.storage.sync.get(['clipEnabled'], (r) => {
    clipEnabled = r.clipEnabled !== false;
    const toggle = $('toggleClip');
    if (toggle) toggle.checked = clipEnabled;
  });
  loadFromLocal(() => {
    lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
    applyFilter();
    checkDriveOnOpen();
    renderDriveStatus();
    checkNotifications();
    checkWelcome();
  });
});

// ── Welcome v2.0 ──────────────────────────────────────────────────────────────
const WELCOME_VERSION = 'v2.0';
const TOTAL_SLIDES    = 7;
let   welcomeSlide    = 0;

function checkWelcome() {
  chrome.storage.sync.get(['welcomeShown'], (r) => {
    if (r.welcomeShown === WELCOME_VERSION) return;
    initWelcome();
    openModal($('welcomeOverlay'));
  });
}

function initWelcome() {
  welcomeSlide = 0;
  renderWelcomeDots();
  gotoWelcomeSlide(0);

  $('btnWelcomeSkip').onclick    = closeWelcome;
  $('btnWelcomeStart').onclick   = closeWelcome;
  $('btnWelcomeTutorial').onclick = () => {
  closeWelcome();
  openModal($('tutorialOverlay'));
  chrome.storage.sync.set({ tutorialSeen: 'v2.0' });
  $('btnTutorial').classList.remove('btn-tutorial-pulse');
  $('tutorialSpotlight').style.display = 'none';
};

  $('btnWelcomeNext').onclick = () => {
    if (welcomeSlide < TOTAL_SLIDES - 1) gotoWelcomeSlide(welcomeSlide + 1);
    else closeWelcome();
  };
  $('btnWelcomePrev').onclick = () => {
    if (welcomeSlide > 0) gotoWelcomeSlide(welcomeSlide - 1);
  };
}

function gotoWelcomeSlide(idx) {
  const slides = document.querySelectorAll('.welcome-slide');
  slides.forEach((s, i) => s.classList.toggle('active', i === idx));
  welcomeSlide = idx;

  // Nav buttons
  $('btnWelcomePrev').style.display = idx === 0 ? 'none' : 'inline-flex';
  const nextBtn = $('btnWelcomeNext');
  if (idx === TOTAL_SLIDES - 1) {
    nextBtn.style.display = 'none';
  } else {
    nextBtn.style.display = 'inline-flex';
    nextBtn.innerHTML = idx === TOTAL_SLIDES - 2
      ? `<span>${i18n.t('w7Btn')}</span>`
      : `<span>${i18n.t('wNext')}</span> <i class="fa-solid fa-chevron-right"></i>`;
  }

  // Dots
  document.querySelectorAll('.welcome-dot').forEach((d, i) => d.classList.toggle('active', i === idx));
}

function renderWelcomeDots() {
  const el = $('welcomeDots');
  el.innerHTML = Array.from({ length: TOTAL_SLIDES }, (_, i) =>
    `<div class="welcome-dot ${i === 0 ? 'active' : ''}" data-i="${i}"></div>`
  ).join('');
  el.querySelectorAll('.welcome-dot').forEach(d =>
    d.addEventListener('click', () => gotoWelcomeSlide(+d.dataset.i))
  );
}

function closeWelcome() {
  closeModal($('welcomeOverlay'));
  chrome.storage.sync.set({ welcomeShown: WELCOME_VERSION });
  setTimeout(checkTutorialPulse, 400);
}

// ── Settings modal ────────────────────────────────────────────────────────────
// ── Modo oscuro ───────────────────────────────────────────────────────────────
(function initDarkMode() {
  chrome.storage.sync.get(['darkMode'], (r) => {
    if (r.darkMode) {
      document.body.classList.add('dark');
      $('iconDark').className = 'fa-solid fa-sun';
    }
  });
})();

$('btnDark').addEventListener('click', () => {
  const isDark = document.body.classList.toggle('dark');
  $('iconDark').className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  chrome.storage.sync.set({ darkMode: isDark });
});

$('btnSettings').addEventListener('click', () => {
  chrome.storage.sync.get(['clipEnabled'], (r) => {
    clipEnabled = r.clipEnabled !== false;
    const toggle = $('toggleClip');
    if (toggle) toggle.checked = clipEnabled;
  });
  renderDriveStatus();
  openModal($('settingsOverlay'));
});
$('btnCloseSettings').addEventListener('click', () => closeModal($('settingsOverlay')));
$('btnDriveRestoreManual').addEventListener('click', () => {
  closeModal($('settingsOverlay'));
  getDriveToken(false, async (token) => {
    if (!token) { showToast(i18n.t('toastDriveError')); return; }
    await openRestoreModal(token);
  });
});

$('btnSaveSettings').addEventListener('click', () => {
  const toggle = $('toggleClip');
  clipEnabled = toggle ? toggle.checked : true;
  chrome.storage.sync.set({ clipEnabled, lastManualBackup: Date.now() });
  closeModal($('settingsOverlay'));
  showToast(i18n.t('toastSettingsSaved'));
  checkNotifications();
});

// ── Notificaciones ────────────────────────────────────────────────────────────
function checkNotifications() {
  chrome.storage.sync.get(['driveEnabled', 'lastManualBackup'], (r) => {
    const notifs = [];

    // Notif 1: Drive no conectado (solo si hay shortcuts)
    if (!r.driveEnabled && allShortcuts.length > 0) {
      notifs.push({
        id: 'no-drive',
        icon: 'fa-brands fa-google-drive',
        color: '#4285F4',
        msg: i18n.t('notifNoDrive'),
        action: () => {
          $('notifDropdown').style.display = 'none';
          renderDriveStatus();
          openModal($('settingsOverlay'));
        }
      });
    }

    // Notif 2: Recordatorio respaldo manual cada 7 días (solo si hay shortcuts)
    const last = r.lastManualBackup || 0;
    const daysSince = (Date.now() - last) / (1000 * 60 * 60 * 24);
    if (daysSince >= 7 && allShortcuts.length > 0) {
      notifs.push({
        id: 'backup-reminder',
        icon: 'fa-solid fa-floppy-disk',
        color: '#dd6b20',
        msg: last === 0 ? i18n.t('notifBackupNever') : i18n.t('notifBackupDays', { days: Math.floor(daysSince) }),
        action: () => {
          btnExport.click();
          chrome.storage.sync.set({ lastManualBackup: Date.now() });
          checkNotifications();
        }
      });
    }

    renderNotifications(notifs);
  });
}

function renderNotifications(notifs) {
  const badge = $('notifBadge');
  const list  = $('notifList');
  if (!badge || !list) return;

  if (notifs.length === 0) {
    badge.style.display = 'none';
    list.innerHTML = `<div class="notif-empty"><i class="fa-solid fa-check-circle"></i> ${i18n.t('notifAllGood')}</div>`;
    return;
  }

  badge.textContent   = notifs.length;
  badge.style.display = 'flex';

  list.innerHTML = notifs.map(n => `
    <div class="notif-item" data-id="${n.id}">
      <i class="${n.icon}" style="color:${n.color}; font-size:16px; flex-shrink:0;"></i>
      <span>${n.msg}</span>
    </div>
  `).join('');

  notifs.forEach(n => {
    const el = list.querySelector(`[data-id="${n.id}"]`);
    if (el && n.action) el.addEventListener('click', n.action);
  });
}

// Toggle dropdown notificaciones
$('btnNotif').addEventListener('click', (e) => {
  e.stopPropagation();
  const dd = $('notifDropdown');
  dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
  if (dd.style.display === 'block') checkNotifications();
});
document.addEventListener('click', () => {
  const dd = $('notifDropdown');
  if (dd) dd.style.display = 'none';
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    const hasShortcutChange = Object.keys(changes).some(k => k.startsWith('sc_'));
    if (hasShortcutChange) loadFromLocal(() => applyFilter());
  }
});

// ── Search ────────────────────────────────────────────────────────────────────
searchInput.addEventListener('input', () => {
  searchQuery = searchInput.value.trim().toLowerCase();
  btnClearSearch.style.display = searchQuery ? 'flex' : 'none';
  currentPage = 1;
  applyFilter();
});

btnClearSearch.addEventListener('click', () => {
  searchInput.value = '';
  searchQuery = '';
  btnClearSearch.style.display = 'none';
  currentPage = 1;
  applyFilter();
  searchInput.focus();
});

// ── Filter ────────────────────────────────────────────────────────────────────
function applyFilter() {
  filtered = searchQuery
    ? allShortcuts.filter(sc =>
        sc.shortcut.toLowerCase().includes(searchQuery) ||
        sc.text.toLowerCase().includes(searchQuery))
    : [...allShortcuts];

  if (activeCategory !== 'all') {
    filtered = filtered.filter(sc => (sc.category || 'General') === activeCategory);
  }

  if (currentSort === 'az')        filtered.sort((a, b) => a.shortcut.localeCompare(b.shortcut));
  else if (currentSort === 'za')   filtered.sort((a, b) => b.shortcut.localeCompare(a.shortcut));
  else if (currentSort === 'uses') filtered.sort((a, b) => (b.uses || 0) - (a.uses || 0));

  if (showDupsOnly) {
    const textCount = {};
    allShortcuts.forEach(sc => {
      const key = sc.text.trim();
      textCount[key] = (textCount[key] || 0) + 1;
    });
    filtered = filtered.filter(sc => textCount[sc.text.trim()] > 1);
  }

  if (showNoDelimOnly) {
    filtered = filtered.filter(sc => /^[a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]/.test(sc.shortcut));
  }

  statsTotal.textContent = allShortcuts.length;

  if (searchQuery && filtered.length !== allShortcuts.length) {
    statsFiltered.textContent = `${filtered.length} resultado${filtered.length !== 1 ? 's' : ''}`;
    statsFiltered.style.display = 'inline';
  } else {
    statsFiltered.style.display = 'none';
  }

  renderPage();
  renderPagination();
  renderHints();
  renderCategories();
}

// ── Category select ───────────────────────────────────────────────────────────
const categorySelectTrigger  = $('categorySelectTrigger');
const categorySelectDropdown = $('categorySelectDropdown');
const categorySelectBox      = $('categorySelect');
const categorySelectLabel    = $('categorySelectLabel');
const inputCategoryHidden    = $('inputCategory');

categorySelectTrigger.addEventListener('click', (e) => {
  e.stopPropagation();
  categorySelectBox.classList.toggle('open');
});

document.addEventListener('click', () => {
  categorySelectBox.classList.remove('open');
});

function populateCategorySelect(selected) {
  const current = selected || inputCategoryHidden.value || 'General';
  inputCategoryHidden.value    = current;
  categorySelectLabel.textContent = current === 'General' ? i18n.t('catGeneral') : current;

  categorySelectDropdown.innerHTML = allCategories.map(c => `
    <div class="custom-select-option ${c.name === current ? 'selected' : ''}" data-value="${c.name}">
      ${c.name === 'General' ? i18n.t('catGeneral') : c.name}
    </div>
  `).join('');

  categorySelectDropdown.querySelectorAll('.custom-select-option').forEach(opt => {
    opt.addEventListener('click', (e) => {
      e.stopPropagation();
      inputCategoryHidden.value       = opt.dataset.value;
      categorySelectLabel.textContent = opt.dataset.value;
      categorySelectDropdown.querySelectorAll('.custom-select-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      categorySelectBox.classList.remove('open');
    });
  });
}

function saveCategories() {
  chrome.storage.sync.set({ categories: allCategories });
}

function loadCategories(cb) {
  chrome.storage.sync.get('categories', r => {
    if (r.categories && r.categories.length) allCategories = r.categories;
    if (cb) cb();
  });
}

function renderCatManager() {
  const el = $('catManagerList');
  if (!el) return;
  el.innerHTML = allCategories.map((c, i) => `
    <div class="cat-manager-row" data-i="${i}">
      <span class="cat-name-label">${c.name === 'General' ? i18n.t('catGeneral') : c.name}</span>
      <input class="cat-name-input" data-i="${i}" value="${c.name}" style="display:none; flex:1;" />
      <small>${c.desc || ''}</small>
      ${c.name !== 'General' ? `
        <button class="btn-cat-edit" data-i="${i}" title="${i18n.t('btnEditar')}"><i class="fa-solid fa-pen"></i></button>
        <button class="btn-cat-save" data-i="${i}" title="${i18n.t('btnGuardar')}" style="display:none"><i class="fa-solid fa-check"></i></button>
        <button class="btn-cat-del" data-i="${i}" title="${i18n.t('btnEliminar')}"><i class="fa-solid fa-trash"></i></button>
      ` : ''}
    </div>
  `).join('');

  el.querySelectorAll('.btn-cat-edit').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = el.querySelector(`.cat-manager-row[data-i="${btn.dataset.i}"]`);
      row.querySelector('.cat-name-label').style.display = 'none';
      row.querySelector('.cat-name-input').style.display = 'block';
      row.querySelector('.btn-cat-edit').style.display = 'none';
      row.querySelector('.btn-cat-save').style.display = 'inline-flex';
      row.querySelector('.cat-name-input').focus();
    });
  });

  el.querySelectorAll('.btn-cat-save').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.i;
      const row = el.querySelector(`.cat-manager-row[data-i="${idx}"]`);
      const newName = row.querySelector('.cat-name-input').value.trim().replace(/\b\w/g, l => l.toUpperCase());
      if (!newName) return;
      if (allCategories.some((c, i) => c.name.toLowerCase() === newName.toLowerCase() && i !== idx)) {
        showToast(i18n.t('toastCatExists', { name: newName }));
        return;
      }
      const oldName = allCategories[idx].name;
      allCategories[idx].name = newName;
      allShortcuts.forEach(sc => { if ((sc.category || 'General') === oldName) sc.category = newName; });
      saveCategories();
      persist();
      renderCatManager();
      renderCategories();
      populateCategorySelect();
      showToast(i18n.t('toastCatRenamed', { name: newName }));
    });
  });

  el.querySelectorAll('.btn-cat-del').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.i;
      const cat = allCategories[idx].name;
      allCategories.splice(idx, 1);
      allShortcuts.forEach(sc => { if ((sc.category || 'General') === cat) sc.category = 'General'; });
      saveCategories();
      persist();
      renderCatManager();
      renderCategories();
    });
  });
}

function openCatModal() {
  $('inputCatName').value = '';
  renderCatManager();
  openModal($('catOverlay'));
}

$('btnNewCategory').addEventListener('click', openCatModal);
$('btnCloseCat').addEventListener('click', () => closeModal($('catOverlay')));

$('btnSaveCat').addEventListener('click', () => {
  const name = $('inputCatName').value.trim().replace(/\b\w/g, l => l.toUpperCase());
  if (!name) return;
  if (allCategories.length >= 50) {
    showToast(i18n.t('toastCatLimit'));
    return;
  }
  if (allCategories.some(c => c.name.toLowerCase() === name.toLowerCase())) {
    showToast(i18n.t('toastCatExists', { name }));
    return;
  }
  allCategories.push({ name, desc: '' });
  allCategories.sort((a, b) => a.name === 'General' ? -1 : b.name === 'General' ? 1 : a.name.localeCompare(b.name));
  saveCategories();
  $('inputCatName').value = '';
  renderCatManager();
  renderCategories();
  showToast(i18n.t('toastCatCreated', { name }));
});

function renderCategories() {
  const counts = { all: allShortcuts.length };
  allShortcuts.forEach(sc => {
    const cat = sc.category || 'General';
    counts[cat] = (counts[cat] || 0) + 1;
  });
  const cats = Object.keys(counts).filter(k => k !== 'all').sort();
  const el = $('categoryList');
  if (!el) return;
  el.innerHTML = `
    <button class="cat-btn ${activeCategory === 'all' ? 'active' : ''}" data-cat="all">
      <i class="fa-solid fa-layer-group"></i> ${i18n.t('catTodos')} <span class="cat-count">${counts.all}</span>
    </button>
    ${cats.map(cat => `
      <button class="cat-btn ${activeCategory === cat ? 'active' : ''}" data-cat="${cat}">
        <i class="fa-solid fa-tag"></i> ${cat === 'General' ? i18n.t('catGeneral') : cat} <span class="cat-count">${counts[cat]}</span>
      </button>
    `).join('')}
  `;
  el.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      activeCategory = btn.dataset.cat;
      currentPage = 1;
      applyFilter();
    });
  });
}

// ── Render list ───────────────────────────────────────────────────────────────
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function hl(text, q) {
  if (!q) return esc(text);
  return esc(text).replace(
    new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi'),
    '<span class="hl">$1</span>'
  );
}

function renderPage() {
  const maxPage = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (currentPage > maxPage) currentPage = maxPage;

  const items = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  if (items.length === 0) {
    listEl.style.display    = 'none';
    emptyState.style.display = 'flex';
    return;
  }

  listEl.style.display    = 'flex';
  emptyState.style.display = 'none';
  listEl.innerHTML = '';

  items.forEach(sc => {
    const row = document.createElement('div');
    row.className = 'sc-row';
    row.innerHTML = `
      <div class="sc-trigger">
        ${hl(sc.shortcut, searchQuery)}
        ${sc.category && sc.category !== 'General' ? `<span class="sc-cat-badge" style="background:${catColor(sc.category)}22; color:${catColor(sc.category)}; border:1px solid ${catColor(sc.category)}44">${sc.category}</span>` : ''}
        ${sc.text.includes('%clip%') ? '<span class="sc-clip-badge" title="%clip%"><i class="fa-solid fa-clipboard"></i></span>' : ''}
        ${/\[[^\]]*\]/.test(sc.text) ? '<span class="sc-clip-badge" title="Contiene placeholders [...]" style="background:rgba(56,161,105,0.12);color:#38a169;border-color:rgba(56,161,105,0.3);"><i class="fa-solid fa-person"></i></span>' : ''}
        ${/^[a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]/.test(sc.shortcut) ? `<span class="sc-clip-badge" title="${i18n.t('warnDelimiter')}" style="background:rgba(221,107,32,0.12);color:#dd6b20;border-color:rgba(221,107,32,0.3);">⚠️</span>` : ''}
      </div>
      <div class="sc-text">${hl(sc.text.replace(/\n/g, ' ↵ '), searchQuery)}</div>
      <div class="sc-actions">
        <button class="action-btn edit" data-id="${sc.id}" title="Editar">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="action-btn del" data-id="${sc.id}" title="Eliminar">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>
    `;
    listEl.appendChild(row);
  });

  listEl.querySelectorAll('.action-btn.edit').forEach(b =>
    b.addEventListener('click', () => openEdit(b.dataset.id)));
  listEl.querySelectorAll('.action-btn.del').forEach(b =>
    b.addEventListener('click', () => openDelete(b.dataset.id)));}

// ── Pagination ────────────────────────────────────────────────────────────────
function renderPagination() {
  const maxPage = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (maxPage <= 1) { paginationEl.innerHTML = ''; return; }

  const range = pageRange(currentPage, maxPage);
  let html = `<button class="page-btn" id="pgPrev" ${currentPage===1?'disabled':''}><i class="fa-solid fa-chevron-left"></i></button>`;

  range.forEach(p => {
    if (p === '…') html += `<span class="page-ellipsis">…</span>`;
    else html += `<button class="page-btn ${p===currentPage?'active':''}" data-p="${p}">${p}</button>`;
  });

  html += `<button class="page-btn" id="pgNext" ${currentPage===maxPage?'disabled':''}><i class="fa-solid fa-chevron-right"></i></button>`;
  paginationEl.innerHTML = html;

  $('pgPrev')?.addEventListener('click', () => goPage(currentPage - 1));
  $('pgNext')?.addEventListener('click', () => goPage(currentPage + 1));
  paginationEl.querySelectorAll('[data-p]').forEach(b =>
    b.addEventListener('click', () => goPage(+b.dataset.p)));
}

function pageRange(cur, max) {
  if (max <= 7) return Array.from({length:max},(_,i)=>i+1);
  if (cur <= 4) return [1,2,3,4,5,'…',max];
  if (cur >= max-3) return [1,'…',max-4,max-3,max-2,max-1,max];
  return [1,'…',cur-1,cur,cur+1,'…',max];
}

function goPage(p) {
  const max = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  currentPage = Math.max(1, Math.min(p, max));
  renderPage();
  renderPagination();
  listEl.scrollIntoView({behavior:'smooth', block:'start'});
}

// ── Hint list ─────────────────────────────────────────────────────────────────
function renderHints() {
  if (!hintList) return;
  if (!allShortcuts.length) {
    hintList.innerHTML = `<p style="font-size:12px;color:var(--text-light)">${i18n.t('hintNoShortcuts')}</p>`;
    return;
  }
  hintList.innerHTML = allShortcuts.slice(0, 10).map(sc => `
    <div class="hint-item">
      <span class="hint-trigger">${esc(sc.shortcut)}</span>
      <span class="hint-preview">${esc(sc.text.substring(0,30))}${sc.text.length>30?'…':''}</span>
    </div>
  `).join('');
}

// ── Test area ─────────────────────────────────────────────────────────────────
testArea.addEventListener('keydown', (e) => {
  if (e.key !== 'Tab') return;
  const val = testArea.value;
  if (!/\[[^\]]*\]/.test(val)) return;
  e.preventDefault();
  e.stopPropagation();
  const match = /\[[^\]]*\]/.exec(val);
  const start  = match.index;
  const end    = start + match[0].length;
  const newVal = val.slice(0, start) + val.slice(end);
  testArea.value = newVal;
  testArea.setSelectionRange(start, start);
});

testArea.addEventListener('input', async () => {
  if (!allShortcuts.length) return;
  const pos    = testArea.selectionStart;
  const before = testArea.value.substring(0, pos);
  const sortedForTest = [...allShortcuts].sort((a, b) => b.shortcut.length - a.shortcut.length);
  for (const sc of sortedForTest) {
    if (!sc.shortcut || !sc.text) continue;
    if (!before.endsWith(sc.shortcut)) continue;

    let expanded = sc.text;
    if (expanded.includes('%clip%')) {
      if (clipEnabled) {
        try {
          const clip = await navigator.clipboard.readText();
          expanded = expanded.replaceAll('%clip%', clip);
        } catch(e) {
          expanded = expanded.replaceAll('%clip%', '');
        }
      } else {
        expanded = expanded.replaceAll('%clip%', '');
      }
    }

    const after  = testArea.value.substring(pos);
    const newVal = before.slice(0, -sc.shortcut.length) + expanded + after;
    sc.uses = (sc.uses || 0) + 1;
    persist();
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(testArea, newVal);
    else testArea.value = newVal;
    const newPos = pos - sc.shortcut.length + expanded.length;
    // Saltar al primer placeholder si existe
    const matchPH = /\[[^\]]*\]/.exec(newVal);
    if (matchPH) {
      const s = matchPH.index;
      const cleanVal = newVal.slice(0, s) + newVal.slice(s + matchPH[0].length);
      testArea.value = cleanVal;
      testArea.setSelectionRange(s, s);
    } else {
      testArea.setSelectionRange(newPos, newPos);
    }
    return;
  }
});

btnClearTest.addEventListener('click', () => {
  testArea.value = '';
  testArea.focus();
});

// ── CRUD ──────────────────────────────────────────────────────────────────────
btnNew.addEventListener('click', () => {
  editingId = null;
  modalTitle.textContent    = i18n.t('modalNewShortcut');
  inputShortcut.value       = '';
  inputText.value           = '';
  $('inputCategory').value  = '';
  populateCategorySelect();
  charCount.textContent = '0';
  const warnEl = $('shortcutDelimiterWarn');
  if (warnEl) warnEl.style.display = 'none';
  openModal(modalOverlay);
  setTimeout(() => inputShortcut.focus(), 80);
});

function openEdit(id) {
  const sc = allShortcuts.find(s => String(s.id) === String(id));
  if (!sc) return;
  editingId = id;
  modalTitle.textContent  = i18n.t('modalEditShortcut');
  inputShortcut.value       = sc.shortcut;
  inputText.value           = sc.text;
  $('inputCategory').value  = sc.category || 'General';
  populateCategorySelect();
  charCount.textContent   = sc.text.length;
  openModal(modalOverlay);
  setTimeout(() => { inputShortcut.focus(); checkDelimiterWarn(); }, 80);
}

inputText.addEventListener('input', () => {
  charCount.textContent = inputText.value.length;
});

inputShortcut.addEventListener('input', checkDelimiterWarn);

btnSaveModal.addEventListener('click', saveShortcut);
inputShortcut.addEventListener('keydown', e => { if (e.key==='Enter') saveShortcut(); });

function checkDelimiterWarn() {
  const shortcut = inputShortcut.value.trim();
  const warnEl   = $('shortcutDelimiterWarn');
  if (!warnEl) return;
  const needsWarn = shortcut.length > 0 && /^[a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]/.test(shortcut);
  warnEl.style.display = needsWarn ? 'flex' : 'none';
}

function saveShortcut() {
  const shortcut = inputShortcut.value.trim();
  const text     = inputText.value.trim();
  const category = ($('inputCategory').value.trim() || 'General').replace(/\b\w/g, l => l.toUpperCase());

  if (!shortcut) { shake(inputShortcut); inputShortcut.focus(); return; }
  if (!text)     { shake(inputText);     inputText.focus();     return; }

  const dup = allShortcuts.find(sc => sc.shortcut === shortcut && String(sc.id) !== String(editingId));
  if (dup) { showToast(i18n.t('toastShortcutExists', { name: shortcut })); shake(inputShortcut); return; }

  if (editingId !== null) {
    const idx = allShortcuts.findIndex(sc => String(sc.id) === String(editingId));
    if (idx !== -1) allShortcuts[idx] = { ...allShortcuts[idx], shortcut, text, category };
  } else {
    allShortcuts.push({ id: crypto.randomUUID(), shortcut, text, category, uses: 0 });
  }

  persist(() => {
    closeModal(modalOverlay);
    showToast(editingId ? i18n.t('toastShortcutUpdated') : i18n.t('toastShortcutCreated'));
    editingId = null;
  });
}

function openDelete(id) {
  const sc = allShortcuts.find(s => String(s.id) === String(id));
  if (!sc) return;
  deleteId = id;
  deleteShortcutName.textContent = sc.shortcut;
  $('deleteWarningText').innerHTML = i18n.t('modalEliminarText', { name: `<strong>${esc(sc.shortcut)}</strong>` });
  openModal(deleteOverlay);
}

btnConfirmDelete.addEventListener('click', () => {
  allShortcuts = allShortcuts.filter(sc => String(sc.id) !== String(deleteId));
  persist(() => {
    closeModal(deleteOverlay);
    showToast(i18n.t('toastShortcutDeleted'));
    deleteId = null;
  });
});

// ── Persist (local, sin límite de cuota) ─────────────────────────────────────
let lastKnownIds = new Set();
let driveDebounceTimer = null;

function persist(cb) {
  const currentIds = new Set(allShortcuts.map(sc => String(sc.id)));
  const dataToSave = {};
  allShortcuts.forEach(sc => { dataToSave[keyFor(sc.id)] = JSON.stringify(sc); });

  const keysToRemove = [...lastKnownIds]
    .filter(id => !currentIds.has(id))
    .map(id => keyFor(id));

  const finishWrite = () => {
    chrome.storage.local.set(dataToSave, () => {
      if (chrome.runtime.lastError) {
        showToast(i18n.t('toastStorageError', { error: chrome.runtime.lastError.message }));
        return;
      }
      lastKnownIds = currentIds;
      applyFilter();
      if (cb) cb();
      // Auto-backup a Drive con debounce de 4 segundos
      scheduleDriveBackup();
    });
  };

  if (keysToRemove.length > 0) {
    chrome.storage.local.remove(keysToRemove, finishWrite);
  } else {
    finishWrite();
  }
}

// ── Google Drive Backup ───────────────────────────────────────────────────────
const DRIVE_APPDATA    = 'appDataFolder';
const DRIVE_BACKUPS    = ['autotext-pro-backup-1.json', 'autotext-pro-backup-2.json', 'autotext-pro-backup-3.json'];

let driveConnected = false;

function getDriveToken(interactive, cb) {
  chrome.identity.getAuthToken({ interactive }, (token) => {
    if (chrome.runtime.lastError || !token) {
      cb(null);
      return;
    }
    cb(token);
  });
}

function scheduleDriveBackup() {
  clearTimeout(driveDebounceTimer);
  driveDebounceTimer = setTimeout(() => {
    getDriveToken(false, (token) => {
      if (token) backupToDrive(token, false);
    });
  }, 4000);
}

async function driveFileId(token, name) {
  const r = await fetch(
    `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='${name}'&fields=files(id)`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const d = await r.json();
  return d.files?.[0]?.id || null;
}

async function driveUpload(token, name, payload, existingId) {
  const boundary = 'autotext_boundary';
  if (existingId) {
    await fetch(`https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=media`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: payload
    });
  } else {
    const meta = JSON.stringify({ name, parents: [DRIVE_APPDATA] });
    const body =
      `--${boundary}\r\nContent-Type: application/json\r\n\r\n${meta}\r\n` +
      `--${boundary}\r\nContent-Type: application/json\r\n\r\n${payload}\r\n` +
      `--${boundary}--`;
    await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': `multipart/related; boundary=${boundary}` },
      body
    });
  }
}

async function backupToDrive(token, showSuccess = true) {
  try {
    const payload = JSON.stringify({
      version: 2,
      savedAt: new Date().toISOString(),
      shortcuts: allShortcuts,
      categories: allCategories
    });

    // Rotar: borrar backup-3, mover 2→3, mover 1→2, crear nuevo 1
    const id3 = await driveFileId(token, DRIVE_BACKUPS[2]);
    if (id3) await fetch(`https://www.googleapis.com/drive/v3/files/${id3}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });

    const id2 = await driveFileId(token, DRIVE_BACKUPS[1]);
    if (id2) {
      await fetch(`https://www.googleapis.com/drive/v3/files/${id2}`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: DRIVE_BACKUPS[2] })
      });
    }

    const id1 = await driveFileId(token, DRIVE_BACKUPS[0]);
    if (id1) {
      await fetch(`https://www.googleapis.com/drive/v3/files/${id1}`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: DRIVE_BACKUPS[1] })
      });
    }

    // Crear nuevo backup-1
    await driveUpload(token, DRIVE_BACKUPS[0], payload, null);

    driveConnected = true;
    chrome.storage.sync.set({ driveEnabled: true, lastDriveBackup: Date.now() });
    renderDriveStatus();
    checkNotifications();
    if (showSuccess) showToast(i18n.t('toastDriveSaved', { count: allShortcuts.length }));
  } catch (e) {
    if (showSuccess) showToast(i18n.t('toastDriveError'));
  }
}

async function fetchBackupList(token) {
  const results = [];
  // Incluir archivo legado (v1 del backup) como candidato
  const allNames = [...DRIVE_BACKUPS, 'autotext-pro-backup.json'];
  for (const name of allNames) {
    try {
      const r = await fetch(
        `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='${name}'&fields=files(id,modifiedTime)`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const d = await r.json();
      const file = d.files?.[0];
      if (!file) continue;
      const dataRes = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await dataRes.json();
      if (!data.shortcuts?.length) continue;
      results.push({ id: file.id, modifiedTime: file.modifiedTime, count: data.shortcuts.length, data });
    } catch(e) {}
  }
  return results;
}

async function restoreFromDriveData(data) {
  // Limpiar todo lo existente primero, luego restaurar
  const existingKeys = await new Promise(res => chrome.storage.local.get(null, r => res(Object.keys(r).filter(k => k.startsWith(SC_PREFIX)))));
  await new Promise(res => chrome.storage.local.remove(existingKeys, res));

  const dataToSave = {};
  data.shortcuts.forEach(sc => { dataToSave[keyFor(sc.id)] = JSON.stringify(sc); });
  if (data.categories) allCategories = data.categories;

  chrome.storage.local.set(dataToSave, () => {
    saveCategories();
    allShortcuts = data.shortcuts;
    lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
    driveConnected = true;
    chrome.storage.sync.set({ driveEnabled: true });
    renderDriveStatus();
    applyFilter();
    showToast(i18n.t('toastDriveRestored', { count: data.shortcuts.length }));
    closeModal($('driveRestoreOverlay'));
  });
}

function timeAgo(isoDate) {
  const diff = (Date.now() - new Date(isoDate)) / 1000;
  if (diff < 3600)  return `Hace ${Math.floor(diff/60)} min`;
  if (diff < 86400) return `Hace ${Math.floor(diff/3600)} h`;
  return `Hace ${Math.floor(diff/86400)} días`;
}

async function openRestoreModal(token) {
  const list = $('driveBackupList');
  list.innerHTML = `<div class="drive-backup-loading"><i class="fa-solid fa-spinner fa-spin"></i> Buscando backups...</div>`;
  openModal($('driveRestoreOverlay'));

  const backups = await fetchBackupList(token);

  if (!backups.length) {
    list.innerHTML = `<div class="drive-backup-empty"><i class="fa-solid fa-cloud-slash"></i> ${i18n.t('toastDriveNoBackup')}</div>`;
    $('btnDriveRestoreYes').style.display = 'none';
    return;
  }

  $('btnDriveRestoreYes').style.display = '';
  let selected = 0;

  function render() {
    list.innerHTML = backups.map((b, i) => `
      <div class="drive-backup-item ${i === selected ? 'selected' : ''}" data-i="${i}">
        <i class="fa-solid fa-cloud" style="color:var(--primary)"></i>
        <div class="drive-backup-info">
          <span class="drive-backup-time">${timeAgo(b.modifiedTime)}</span>
          <span class="drive-backup-count">${b.count} shortcuts</span>
        </div>
        ${i === selected ? '<i class="fa-solid fa-check" style="color:var(--primary); margin-left:auto;"></i>' : ''}
      </div>
    `).join('');
    list.querySelectorAll('.drive-backup-item').forEach(el => {
      el.addEventListener('click', () => { selected = +el.dataset.i; render(); });
    });
  }
  render();

  $('btnDriveRestoreYes').onclick = () => restoreFromDriveData(backups[selected].data);
  $('btnDriveRestoreNo').onclick  = () => closeModal($('driveRestoreOverlay'));
}

async function checkDriveOnOpen() {
  if (allShortcuts.length > 0) {
    chrome.storage.sync.get('driveEnabled', (r) => {
      if (r.driveEnabled) driveConnected = true;
      renderDriveStatus();
    });
    return;
  }

  // Local vacío: buscar backups en Drive
  getDriveToken(false, async (token) => {
    if (!token) return;
    try {
      await openRestoreModal(token);
    } catch(e) {}
  });
}

function renderDriveStatus() {
  const el = $('driveStatusArea');
  if (!el) return;

  getDriveToken(false, (token) => {
    if (token) {
      driveConnected = true;
      el.innerHTML = `
        <div class="drive-status connected">
          <i class="fa-brands fa-google-drive"></i>
          <span>${i18n.t('driveConnected')}</span>
          <button id="btnDriveBackupNow" class="btn-drive-action">
            <i class="fa-solid fa-cloud-arrow-up"></i> ${i18n.t('driveBackupNow')}
          </button>
          <button id="btnDriveDisconnect" class="btn-drive-disconnect">
            <i class="fa-solid fa-link-slash"></i> ${i18n.t('driveDisconnect')}
          </button>
        </div>
      `;
      $('btnDriveBackupNow').addEventListener('click', () => {
        getDriveToken(false, (t) => {
          if (t) backupToDrive(t, true);
          else showToast(i18n.t('toastDriveError'));
        });
      });
      $('btnDriveDisconnect').addEventListener('click', () => {
        fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`)
          .finally(() => {
            chrome.identity.removeCachedAuthToken({ token }, () => {
              driveConnected = false;
              chrome.storage.sync.set({ driveEnabled: false });
              renderDriveStatus();
              checkNotifications();
              showToast(i18n.t('driveDisconnected'));
            });
          });
      });
    } else {
      driveConnected = false;
      el.innerHTML = `
        <div class="drive-status disconnected">
          <i class="fa-brands fa-google-drive"></i>
          <span>${i18n.t('driveDisconnectedMsg')}</span>
          <button id="btnDriveConnect" class="btn-drive-action">
            <i class="fa-brands fa-google"></i> ${i18n.t('driveConnect')}
          </button>
        </div>
      `;
      $('btnDriveConnect').addEventListener('click', () => {
        getDriveToken(true, (t) => {
          if (t) {
            backupToDrive(t, true);
          } else {
            showToast(i18n.t('toastDriveError'));
          }
        });
      });
    }
  });
}

// ── Delete All ────────────────────────────────────────────────────────────────
const btnDeleteAll = $('btnDeleteAll');

btnDeleteAll.addEventListener('click', () => {
  if (!allShortcuts.length) { showToast(i18n.t('toastNoShortcuts')); return; }
  $('deleteAllWarningText').innerHTML = i18n.t('deleteAll1Text', { count: `<strong>${allShortcuts.length}</strong>` });
  openModal($('deleteAllOverlay1'));
});

$('btnDeleteAllNo1').addEventListener('click',    () => closeModal($('deleteAllOverlay1')));
$('btnCloseDeleteAll1').addEventListener('click', () => closeModal($('deleteAllOverlay1')));

$('btnDeleteAllSi1').addEventListener('click', () => {
  closeModal($('deleteAllOverlay1'));
  openModal($('deleteAllOverlay2'));
});

$('btnDeleteAllNo2').addEventListener('click',    () => closeModal($('deleteAllOverlay2')));
$('btnCloseDeleteAll2').addEventListener('click', () => closeModal($('deleteAllOverlay2')));

$('btnDeleteAllConfirm').addEventListener('click', () => {
  const blob = new Blob(
    [JSON.stringify({ version: 2, shortcuts: allShortcuts, categories: allCategories }, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a   = Object.assign(document.createElement('a'), {
    href: url,
    download: `autotext-pro-backup-${stamp()}.json`
  });
  a.click();
  URL.revokeObjectURL(url);
  closeModal($('deleteAllOverlay2'));
  $('inputDeleteConfirm').value = '';
  $('btnDeleteAllFinal').disabled = false;
  openModal($('deleteAllOverlay3'));
});

$('inputDeleteConfirm').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  if ($('inputDeleteConfirm').value === 'B0rr4r') $('btnDeleteAllFinal').click();
});

$('btnDeleteAllNo3').addEventListener('click',    () => closeModal($('deleteAllOverlay3')));
$('btnCloseDeleteAll3').addEventListener('click', () => closeModal($('deleteAllOverlay3')));

$('btnDeleteAllFinal').addEventListener('click', () => {
  if ($('inputDeleteConfirm').value !== 'B0rr4r') {
    showToast(i18n.t('toastWrongWord'));
    const overlay = $('deleteAllOverlay3');
    overlay.classList.remove('modal-shake');
    void overlay.offsetWidth;
    overlay.classList.add('modal-shake');
    setTimeout(() => overlay.classList.remove('modal-shake'), 500);
    return;
  }
  allShortcuts = [];
  persist(() => {
    closeModal($('deleteAllOverlay3'));
    showToast(i18n.t('toastAllDeleted'));
  });
});

// ── Export ────────────────────────────────────────────────────────────────────
btnExport.addEventListener('click', () => {
  const blob = new Blob(
    [JSON.stringify({ version: 2, shortcuts: allShortcuts, categories: allCategories }, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a   = Object.assign(document.createElement('a'), {
    href: url,
    download: `autotext-pro-${stamp()}.json`
  });
  a.click();
  URL.revokeObjectURL(url);
  showToast(i18n.t('toastExported', { count: allShortcuts.length }));
});

// ── Shortcut / para búsqueda ──────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === '/' && document.activeElement !== searchInput &&
      !document.activeElement.closest('.modal-overlay') &&
      !document.activeElement.closest('textarea') &&
      !document.activeElement.closest('input')) {
    e.preventDefault();
    searchInput.focus();
  }
  if (e.key === 'Escape') searchInput.blur();
});

// ── Sort & Filtros ────────────────────────────────────────────────────────────
let currentSort     = 'created';
let showDupsOnly    = false;
let showNoDelimOnly = false;
document.getElementById('btnShowDups').addEventListener('click', () => {
  showDupsOnly    = true;
  showNoDelimOnly = false;
  document.getElementById('btnClearFilter').style.display = 'inline-flex';
  document.getElementById('btnShowDups').style.display = 'none';
  document.getElementById('btnShowNoDelim').style.display = 'inline-flex';
  currentPage = 1;
  applyFilter();
});

document.getElementById('btnShowNoDelim').addEventListener('click', () => {
  showNoDelimOnly = true;
  showDupsOnly    = false;
  document.getElementById('btnClearFilter').style.display = 'inline-flex';
  document.getElementById('btnShowNoDelim').style.display = 'none';
  document.getElementById('btnShowDups').style.display = 'inline-flex';
  currentPage = 1;
  applyFilter();
});

document.getElementById('btnClearFilter').addEventListener('click', () => {
  showDupsOnly    = false;
  showNoDelimOnly = false;
  document.getElementById('btnClearFilter').style.display = 'none';
  document.getElementById('btnShowDups').style.display = 'inline-flex';
  document.getElementById('btnShowNoDelim').style.display = 'inline-flex';
  currentPage = 1;
  applyFilter();
});

document.addEventListener('click', e => {
  const btn = e.target.closest('.sort-btn');
  if (!btn) return;
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentSort = btn.dataset.sort;
  currentPage = 1;
  applyFilter();
});

// Resaltar sort btn activo con color primario al iniciar
document.querySelectorAll('.sort-btn').forEach(b => {
  if (b.dataset.sort === currentSort) b.classList.add('active');
});

// ── Import & Drag/Drop ────────────────────────────────────────────────────────
const dropZone = $('dropZone');

function processFile(file) {
  if (!file) return;
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['json','yaml','yml','xml','csv'].includes(ext)) {
    showToast(i18n.t('toastFormatsAccepted'));
    return;
  }

  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const txt = ev.target.result;
      let raw = [];

      if (ext === 'json') {
        const parsed = JSON.parse(txt);
        if (Array.isArray(parsed)) {
          raw = parsed;
        } else if (parsed.shortcuts && Array.isArray(parsed.shortcuts)) {
          raw = parsed.shortcuts;
          if (parsed.categories && Array.isArray(parsed.categories)) {
            parsed.categories.forEach(c => {
              if (!allCategories.some(e => e.name.toLowerCase() === c.name.toLowerCase())) {
                allCategories.push(c);
              }
            });
          }
          raw.forEach(sc => {
            const cat = sc.category;
            if (cat && cat !== 'General' && !allCategories.some(e => e.name.toLowerCase() === cat.toLowerCase())) {
              allCategories.push({ name: cat, desc: '' });
            }
          });
          allCategories.sort((a, b) => a.name === 'General' ? -1 : b.name === 'General' ? 1 : a.name.localeCompare(b.name));
          saveCategories();
          renderCategories();
        } else if (typeof parsed === 'object' && parsed !== null) {
          const values = Object.values(parsed);
          if (values.length && typeof values[0] === 'object' && values[0].trigger) {
            raw = values.map(e => ({ shortcut: e.trigger, text: e.body }));
          } else {
            raw = Object.entries(parsed).map(([key, val]) => ({ shortcut: key, text: String(val) }));
          }
        }
      } else if (ext === 'yaml' || ext === 'yml') {
        const matches = [...txt.matchAll(/- trigger:\s*['"]?(.+?)['"]?\s*\n\s+replace:\s*([\s\S]*?)(?=\n- trigger:|\n*$)/gm)];
        raw = matches.map(m => ({ shortcut: m[1].trim(), text: m[2].trim() }));
      } else if (ext === 'xml') {
        const doc = new DOMParser().parseFromString(txt, 'text/xml');
        doc.querySelectorAll('snippet').forEach(n => {
          const shortcut = n.querySelector('abbreviation')?.textContent?.trim();
          const text     = n.querySelector('string')?.textContent?.trim();
          if (shortcut && text) raw.push({ shortcut, text });
        });
        if (!raw.length) {
          doc.querySelectorAll('phrase').forEach(n => {
            const shortcut = n.querySelector('trigger')?.textContent?.trim();
            const text     = n.querySelector('insert')?.textContent?.trim();
            if (shortcut && text) raw.push({ shortcut, text });
          });
        }
      } else if (ext === 'csv') {
        const lines = txt.split('\n').map(l => l.trim()).filter(Boolean);
        const start = lines[0]?.toLowerCase().startsWith('shortcut') ? 1 : 0;
        lines.slice(start).forEach(line => {
          const comma = line.indexOf(',');
          if (comma === -1) return;
          const shortcut = line.slice(0, comma).trim().replace(/^"|"$/g, '');
          const text     = line.slice(comma + 1).trim().replace(/^"|"$/g, '');
          if (shortcut && text) raw.push({ shortcut, text });
        });
      }

      const valid = raw.filter(sc => sc.shortcut && sc.text).map(sc => ({
        id: crypto.randomUUID(),
        shortcut: String(sc.shortcut).trim(),
        text: String(sc.text),
        category: sc.category || 'General',
        uses: sc.uses || 0,
      }));

      if (!valid.length) throw new Error(i18n.t('toastNoValidShortcuts'));

      const duplicates = valid.filter(imp => allShortcuts.some(s => s.shortcut === imp.shortcut));
      const newOnes    = valid.filter(imp => !allShortcuts.some(s => s.shortcut === imp.shortcut));

      if (duplicates.length > 0) {
        const dupOverlay = $('dupOverlay');
        const dupMessage = $('dupMessage');
        dupMessage.textContent = duplicates.length === 1
          ? i18n.t('dupMsgSingle', { name: duplicates[0].shortcut })
          : i18n.t('dupMsgMultiple', { count: duplicates.length });
        openModal(dupOverlay);

        const cleanup = () => {
          $('btnDupOverwrite').onclick = null;
          $('btnDupRename').onclick    = null;
          $('btnDupCancel').onclick    = null;
          $('btnCloseDup').onclick     = null;
          closeModal(dupOverlay);
        };

        $('btnDupOverwrite').onclick = () => {
          cleanup();
          newOnes.forEach(imp => allShortcuts.push(imp));
          duplicates.forEach(imp => {
            const idx = allShortcuts.findIndex(s => s.shortcut === imp.shortcut);
            if (idx !== -1) allShortcuts[idx] = Object.assign(allShortcuts[idx], imp);
          });
          persist(() => {
            const msg = [newOnes.length && `${newOnes.length} ${i18n.t('toastNew')}`, duplicates.length && `${duplicates.length} ${i18n.t('toastOverwritten')}`].filter(Boolean).join(', ');
            showToast(i18n.t('toastImported', { msg }));
          });
        };

        $('btnDupRename').onclick = () => {
          cleanup();
          newOnes.forEach(imp => allShortcuts.push(imp));
          duplicates.forEach(imp => {
            let base = imp.shortcut, n = 2, candidate = `${base[0]}${n}${base.slice(1)}`;
            while (allShortcuts.some(s => s.shortcut === candidate)) { n++; candidate = `${base[0]}${n}${base.slice(1)}`; }
            allShortcuts.push({ ...imp, shortcut: candidate, id: crypto.randomUUID() });
          });
          persist(() => {
            const msg = [newOnes.length && `${newOnes.length} ${i18n.t('toastNew')}`, duplicates.length && `${duplicates.length} ${i18n.t('toastRenamed')}`].filter(Boolean).join(', ');
            showToast(i18n.t('toastImported', { msg }));
          });
        };

        $('btnDupCancel').onclick = () => { cleanup(); newOnes.forEach(imp => allShortcuts.push(imp)); persist(() => showToast(i18n.t('toastImportedAddedSkipped', { added: newOnes.length, skipped: duplicates.length }))); };
        $('btnCloseDup').onclick  = () => { cleanup(); };
        return;
      }

      let added = 0, updated = 0;
      valid.forEach(imp => {
        const idx = allShortcuts.findIndex(s => s.shortcut === imp.shortcut);
        if (idx !== -1) { allShortcuts[idx] = Object.assign(allShortcuts[idx], imp); updated++; }
        else { allShortcuts.push(imp); added++; }
      });

      persist(() => {
        const msg = [added && `${added} ${i18n.t('toastNew')}`, updated && `${updated} ${i18n.t('toastUpdated')}`].filter(Boolean).join(', ');
        showToast(i18n.t('toastImported', { msg }));
      });
    } catch (err) {
      showToast(i18n.t('toastImportError', { error: err.message }));
    }
    fileInput.value = '';
  };
  reader.readAsText(file);
}

btnImport.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => processFile(e.target.files[0]));

document.addEventListener('dragenter', e => {
  if (e.dataTransfer?.types?.includes('Files')) dropZone.style.display = 'flex';
});
document.addEventListener('dragover', e => {
  e.preventDefault();
  dropZone.classList.add('over');
});
document.addEventListener('dragleave', e => {
  if (e.relatedTarget === null || e.relatedTarget === document.documentElement) {
    dropZone.style.display = 'none';
    dropZone.classList.remove('over');
  }
});
document.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.style.display = 'none';
  dropZone.classList.remove('over');
  processFile(e.dataTransfer?.files?.[0]);
});

// ── Privacy Policy ────────────────────────────────────────────────────────────
$('btnPrivacy').addEventListener('click',        () => openModal($('privacyOverlay')));
$('btnClosePrivacy').addEventListener('click',   () => closeModal($('privacyOverlay')));
$('btnClosePrivacy2').addEventListener('click',  () => closeModal($('privacyOverlay')));

// ── Tutorial ──────────────────────────────────────────────────────────────────
$('btnTutorial').addEventListener('click', () => {
  openModal($('tutorialOverlay'));
  chrome.storage.sync.set({ tutorialSeen: 'v2.0' });
  $('btnTutorial').classList.remove('btn-tutorial-pulse');
  $('tutorialSpotlight').style.display = 'none';
});

function checkTutorialPulse() {
  chrome.storage.sync.get(['welcomeShown', 'tutorialSeen'], (r) => {
    // Solo pulsar si: welcome ya fue mostrado Y tutorial no ha sido visto
    if (r.welcomeShown === 'v2.0' && r.tutorialSeen !== 'v2.0') {
      $('btnTutorial').classList.add('btn-tutorial-pulse');
      $('tutorialSpotlight').style.display = 'block';
    }
  });
}
$('btnCloseTutorial').addEventListener('click',  () => closeModal($('tutorialOverlay')));
$('btnCloseTutorial2').addEventListener('click', () => closeModal($('tutorialOverlay')));

// ── Modal helpers ─────────────────────────────────────────────────────────────
function openModal(el)  { el.classList.add('open'); }
function closeModal(el) { el.classList.remove('open'); }

btnCancelModal.addEventListener('click',  () => closeModal(modalOverlay));
btnCloseModal.addEventListener('click',   () => closeModal(modalOverlay));
btnCancelDelete.addEventListener('click', () => closeModal(deleteOverlay));
btnCloseDelete.addEventListener('click',  () => closeModal(deleteOverlay));

const ALL_MODALS = [
  'modalOverlay','deleteOverlay','deleteAllOverlay1','deleteAllOverlay2',
  'deleteAllOverlay3','privacyOverlay','tutorialOverlay','catOverlay',
  'dupOverlay','driveRestoreOverlay','settingsOverlay'
];

ALL_MODALS.forEach(id => {
  const el = $(id);
  if (!el) return;
  el.addEventListener('click', e => { if (e.target === el) closeModal(el); });
});

document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  ALL_MODALS.forEach(id => {
    const el = $(id);
    if (el && el.classList.contains('open')) closeModal(el);
  });
});

// ── Utils ─────────────────────────────────────────────────────────────────────
let toastT;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => toast.classList.remove('show'), 2600);
}

function shake(el) {
  el.style.animation = 'none';
  el.getBoundingClientRect();
  el.style.animation = 'shake 0.3s ease';
  setTimeout(() => (el.style.animation = ''), 400);
}

function stamp() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
}
