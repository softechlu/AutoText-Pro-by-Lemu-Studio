// AutoText Pro — Options Page JS v3
'use strict';

const PAGE_SIZE = 25;
let allShortcuts   = [];
let filtered       = [];
let currentPage    = 1;
let searchQuery    = '';
let editingId      = null;
let deleteId       = null;
let activeCategory = 'all';
let allCategories  = [{ name: 'General', desc: '' }];

// ── DOM ───────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

const searchInput      = $('searchInput');
const btnClearSearch   = $('btnClearSearch');
const btnNew           = $('btnNew');
const btnExport        = $('btnExport');
const btnImport        = $('btnImport');
// const btnDark = $('btnDark'); // PENDIENTE: modo oscuro desactivado
const fileInput        = $('fileInput');
const listEl           = $('shortcutsList');
const emptyState       = $('emptyState');
const paginationEl     = $('pagination');
const statsTotal       = $('statsTotal');
const statsFiltered    = $('statsFiltered');

const modalOverlay     = $('modalOverlay');
const modalTitle       = $('modalTitle');
const inputShortcut    = $('inputShortcut');
const inputText        = $('inputText');
const charCount        = $('charCount');
const btnSaveModal     = $('btnSaveModal');
const btnCancelModal   = $('btnCancelModal');
const btnCloseModal    = $('btnCloseModal');

const deleteOverlay    = $('deleteOverlay');
const deleteShortcutName = $('deleteShortcutName');
const btnConfirmDelete = $('btnConfirmDelete');
const btnCancelDelete  = $('btnCancelDelete');
const btnCloseDelete   = $('btnCloseDelete');

const testArea         = $('testArea');
const btnClearTest     = $('btnClearTest');
const hintList         = $('hintList');
const toast            = $('toast');

// ── Idioma (i18n) ───────────────────────────────────────────────────────────────
const langSelectTrigger  = $('langSelectTrigger');
const langSelectDropdown = $('langSelectDropdown');
const langSelectBox      = $('langSelect');
const langSelectLabel    = $('langSelectLabel');

langSelectTrigger.addEventListener('click', (e) => {
  e.stopPropagation();
  langSelectBox.classList.toggle('open');
});

langSelectDropdown.querySelectorAll('.custom-select-option').forEach(opt => {
  opt.addEventListener('click', (e) => {
    e.stopPropagation();
    i18n.setLanguage(opt.dataset.lang, () => {
      applyTranslations();
      applyFilter();
    });
    langSelectBox.classList.remove('open');
  });
});

document.addEventListener('click', () => {
  langSelectBox.classList.remove('open');
});

function applyTranslations() {
  langSelectLabel.textContent = i18n.current.toUpperCase();

  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.innerHTML = i18n.t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = i18n.t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = i18n.t(el.dataset.i18nTitle);
  });
}

// ── Almacenamiento atómico: cada shortcut es su propio ítem (prefijo sc_) ─────
const SC_PREFIX = 'sc_';

function keyFor(id) { return SC_PREFIX + id; }

function loadFromSync(cb) {
  chrome.storage.sync.get(null, (r) => {
    if (r.categories && r.categories.length) allCategories = r.categories;
    allShortcuts = [];

    Object.keys(r).forEach(key => {
      if (!key.startsWith(SC_PREFIX)) return;
      try {
        const item = JSON.parse(r[key]);
        allShortcuts.push(item);
      } catch (e) { /* ítem corrupto, se ignora */ }
    });

    // Migración automática de formato viejo (shortcuts / shortcuts_N)
    if (!allShortcuts.length) {
      let legacy = [];
      let i = 0;
      while (r['shortcuts_' + i]) { legacy = legacy.concat(r['shortcuts_' + i]); i++; }
      if (i === 0 && Array.isArray(r.shortcuts)) legacy = r.shortcuts;

      if (legacy.length) {
        allShortcuts = legacy.map(item => Array.isArray(item)
          ? { shortcut: item[0], text: item[1], category: item[2] || 'General', id: item[3] || String(Date.now() + Math.random()), uses: item[4] || 0 }
          : item
        );
        migrateToAtomic(); // guarda ya en el formato nuevo y limpia lo viejo
      }
    }

    if (cb) cb();
  });
}

function migrateToAtomic() {
  const dataToSave = {};
  allShortcuts.forEach(sc => { dataToSave[keyFor(sc.id)] = JSON.stringify(sc); });
  chrome.storage.sync.set(dataToSave, () => {
    chrome.storage.sync.get(null, (allKeys) => {
      const oldKeys = Object.keys(allKeys).filter(k => k === 'shortcuts' || k.startsWith('shortcuts_'));
      if (oldKeys.length) chrome.storage.sync.remove(oldKeys);
    });
  });
}

// ── Init ──────────────────────────────────────────────────────────────────────
$('footerYear').textContent = new Date().getFullYear();
$('footerVersion').textContent = chrome.runtime.getManifest().version;

i18n.init(() => {
  applyTranslations();
  loadFromSync(() => {
    lastKnownIds = new Set(allShortcuts.map(sc => String(sc.id)));
    applyFilter();
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') {
    loadFromSync(() => applyFilter());
  }
});

// ── Search ────────────────────────────────────────────────────────────────────
searchInput.addEventListener('input', () => {
  searchQuery = searchInput.value.trim().toLowerCase();
  btnClearSearch.style.display = searchQuery ? 'flex' : 'none';
  currentPage = 1;
  applyFilter();
});

btnClearSearch.addEventListener('click', () => {
  searchInput.value = '';
  searchQuery = '';
  btnClearSearch.style.display = 'none';
  currentPage = 1;
  applyFilter();
  searchInput.focus();
});

// ── Filter ────────────────────────────────────────────────────────────────────
function applyFilter() {
  filtered = searchQuery
    ? allShortcuts.filter(sc =>
        sc.shortcut.toLowerCase().includes(searchQuery) ||
        sc.text.toLowerCase().includes(searchQuery))
    : [...allShortcuts];

  if (activeCategory !== 'all') {
    filtered = filtered.filter(sc => (sc.category || 'General') === activeCategory);
  }

if (currentSort === 'az')   filtered.sort((a, b) => a.shortcut.localeCompare(b.shortcut));
  else if (currentSort === 'za')   filtered.sort((a, b) => b.shortcut.localeCompare(a.shortcut));
  else if (currentSort === 'uses') filtered.sort((a, b) => (b.uses || 0) - (a.uses || 0));

  if (showDupsOnly) {
    const textCount = {};
    allShortcuts.forEach(sc => {
      const key = sc.text.trim();
      textCount[key] = (textCount[key] || 0) + 1;
    });
    filtered = filtered.filter(sc => textCount[sc.text.trim()] > 1);
  }

  statsTotal.textContent = allShortcuts.length;

  if (searchQuery && filtered.length !== allShortcuts.length) {
    statsFiltered.textContent = `${filtered.length} resultado${filtered.length !== 1 ? 's' : ''}`;
    statsFiltered.style.display = 'inline';
  } else {
    statsFiltered.style.display = 'none';
  }

renderPage();
  renderPagination();
  renderHints();
  renderCategories();
}

// Inicializar dropdown de categoría UNA sola vez
const categorySelectTrigger  = $('categorySelectTrigger');
const categorySelectDropdown = $('categorySelectDropdown');
const categorySelectBox      = $('categorySelect');
const categorySelectLabel    = $('categorySelectLabel');
const inputCategoryHidden    = $('inputCategory');

categorySelectTrigger.addEventListener('click', (e) => {
  e.stopPropagation();
  categorySelectBox.classList.toggle('open');
});

document.addEventListener('click', () => {
  categorySelectBox.classList.remove('open');
});

function populateCategorySelect(selected) {
  const current = selected || inputCategoryHidden.value || 'General';
  inputCategoryHidden.value    = current;
  categorySelectLabel.textContent = current === 'General' ? i18n.t('catGeneral') : current;

  categorySelectDropdown.innerHTML = allCategories.map(c => `
    <div class="custom-select-option ${c.name === current ? 'selected' : ''}" data-value="${c.name}">
      ${c.name === 'General' ? i18n.t('catGeneral') : c.name}
    </div>
  `).join('');

  categorySelectDropdown.querySelectorAll('.custom-select-option').forEach(opt => {
    opt.addEventListener('click', (e) => {
      e.stopPropagation();
      inputCategoryHidden.value       = opt.dataset.value;
      categorySelectLabel.textContent = opt.dataset.value;
      categorySelectDropdown.querySelectorAll('.custom-select-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      categorySelectBox.classList.remove('open');
    });
  });
}

function saveCategories() {
  chrome.storage.sync.set({ categories: allCategories });
}

function loadCategories(cb) {
  chrome.storage.sync.get('categories', r => {
    if (r.categories && r.categories.length) allCategories = r.categories;
    if (cb) cb();
  });
}

function renderCatManager() {
  const el = $('catManagerList');
  if (!el) return;
  el.innerHTML = allCategories.map((c, i) => `
    <div class="cat-manager-row" data-i="${i}">
      <span class="cat-name-label">${c.name === 'General' ? i18n.t('catGeneral') : c.name}</span>
      <input class="cat-name-input" data-i="${i}" value="${c.name}" style="display:none; flex:1;" />
      <small>${c.desc || ''}</small>
      ${c.name !== 'General' ? `
        <button class="btn-cat-edit" data-i="${i}" title="${i18n.t('btnEditar')}"><i class="fa-solid fa-pen"></i></button>
        <button class="btn-cat-save" data-i="${i}" title="${i18n.t('btnGuardar')}" style="display:none"><i class="fa-solid fa-check"></i></button>
        <button class="btn-cat-del" data-i="${i}" title="${i18n.t('btnEliminar')}"><i class="fa-solid fa-trash"></i></button>
      ` : ''}
    </div>
  `).join('');

  el.querySelectorAll('.btn-cat-edit').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = el.querySelector(`.cat-manager-row[data-i="${btn.dataset.i}"]`);
      row.querySelector('.cat-name-label').style.display = 'none';
      row.querySelector('.cat-name-input').style.display = 'block';
      row.querySelector('.btn-cat-edit').style.display = 'none';
      row.querySelector('.btn-cat-save').style.display = 'inline-flex';
      row.querySelector('.cat-name-input').focus();
    });
  });

  el.querySelectorAll('.btn-cat-save').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.i;
      const row = el.querySelector(`.cat-manager-row[data-i="${idx}"]`);
      const newName = row.querySelector('.cat-name-input').value.trim().replace(/\b\w/g, l => l.toUpperCase());
      if (!newName) return;
      if (allCategories.some((c, i) => c.name.toLowerCase() === newName.toLowerCase() && i !== idx)) {
        showToast(i18n.t('toastCatExists', { name: newName }));
        return;
      }
      const oldName = allCategories[idx].name;
      allCategories[idx].name = newName;
      allShortcuts.forEach(sc => { if ((sc.category || 'General') === oldName) sc.category = newName; });
      saveCategories();
      persist();
      renderCatManager();
      renderCategories();
      populateCategorySelect();
      showToast(i18n.t('toastCatRenamed', { name: newName }));
    });
  });

  el.querySelectorAll('.btn-cat-del').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.i;
      const cat = allCategories[idx].name;
      allCategories.splice(idx, 1);
      allShortcuts.forEach(sc => { if ((sc.category || 'General') === cat) sc.category = 'General'; });
      saveCategories();
      persist();
      renderCatManager();
      renderCategories();
    });
  });
}

function openCatModal() {
  $('inputCatName').value = '';
  renderCatManager();
  openModal($('catOverlay'));
}

$('btnNewCategory').addEventListener('click', openCatModal);
$('btnCloseCat').addEventListener('click', () => closeModal($('catOverlay')));

$('btnSaveCat').addEventListener('click', () => {
  const name = $('inputCatName').value.trim().replace(/\b\w/g, l => l.toUpperCase());
  if (!name) return;
  if (allCategories.length >= 50) {
    showToast(i18n.t('toastCatLimit'));
    return;
  }
  if (allCategories.some(c => c.name.toLowerCase() === name.toLowerCase())) {
    showToast(i18n.t('toastCatExists', { name }));
    return;
  }
  allCategories.push({ name, desc: '' });
  allCategories.sort((a, b) => a.name === 'General' ? -1 : b.name === 'General' ? 1 : a.name.localeCompare(b.name));
  saveCategories();
  $('inputCatName').value = '';
  renderCatManager();
  renderCategories();
  showToast(i18n.t('toastCatCreated', { name }));
});

function renderCategories() {
  const counts = { all: allShortcuts.length };
  allShortcuts.forEach(sc => {
    const cat = sc.category || 'General';
    counts[cat] = (counts[cat] || 0) + 1;
  });
  const cats = Object.keys(counts).filter(k => k !== 'all').sort();
  const el = $('categoryList');
  if (!el) return;
  el.innerHTML = `
    <button class="cat-btn ${activeCategory === 'all' ? 'active' : ''}" data-cat="all">
      <i class="fa-solid fa-layer-group"></i> ${i18n.t('catTodos')} <span class="cat-count">${counts.all}</span>
    </button>
    ${cats.map(cat => `
      <button class="cat-btn ${activeCategory === cat ? 'active' : ''}" data-cat="${cat}">
        <i class="fa-solid fa-tag"></i> ${cat === 'General' ? i18n.t('catGeneral') : cat} <span class="cat-count">${counts[cat]}</span>
      </button>
    `).join('')}
  `;
  el.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      activeCategory = btn.dataset.cat;
      currentPage = 1;
      applyFilter();
    });
  });
}

// ── Render list ───────────────────────────────────────────────────────────────
function esc(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function hl(text, q) {
  if (!q) return esc(text);
  return esc(text).replace(
    new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi'),
    '<span class="hl">$1</span>'
  );
}

function renderPage() {
  const maxPage = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (currentPage > maxPage) currentPage = maxPage;

  const items = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  if (items.length === 0) {
    listEl.style.display   = 'none';
    emptyState.style.display = 'flex';
    return;
  }

  listEl.style.display    = 'flex';
  emptyState.style.display = 'none';
  listEl.innerHTML = '';

  items.forEach(sc => {
    const row = document.createElement('div');
    row.className = 'sc-row';
    row.innerHTML = `
      <div class="sc-trigger">
        ${hl(sc.shortcut, searchQuery)}
        ${sc.category && sc.category !== 'General' ? `<span class="sc-cat-badge">${sc.category}</span>` : ''}
      </div>
      <div class="sc-text">${hl(sc.text.replace(/\n/g, ' ↵ '), searchQuery)}</div>
      <div class="sc-actions">
        <button class="action-btn edit" data-id="${sc.id}" title="Editar">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="action-btn del" data-id="${sc.id}" title="Eliminar">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>
    `;
    listEl.appendChild(row);
  });

  listEl.querySelectorAll('.action-btn.edit').forEach(b =>
    b.addEventListener('click', () => openEdit(+b.dataset.id)));
  listEl.querySelectorAll('.action-btn.del').forEach(b =>
    b.addEventListener('click', () => openDelete(+b.dataset.id)));
}

// ── Pagination ────────────────────────────────────────────────────────────────
function renderPagination() {
  const maxPage = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (maxPage <= 1) { paginationEl.innerHTML = ''; return; }

  const range = pageRange(currentPage, maxPage);
  let html = `<button class="page-btn" id="pgPrev" ${currentPage===1?'disabled':''}><i class="fa-solid fa-chevron-left"></i></button>`;

  range.forEach(p => {
    if (p === '…') html += `<span class="page-ellipsis">…</span>`;
    else html += `<button class="page-btn ${p===currentPage?'active':''}" data-p="${p}">${p}</button>`;
  });

  html += `<button class="page-btn" id="pgNext" ${currentPage===maxPage?'disabled':''}><i class="fa-solid fa-chevron-right"></i></button>`;
  paginationEl.innerHTML = html;

  $('pgPrev')?.addEventListener('click', () => goPage(currentPage - 1));
  $('pgNext')?.addEventListener('click', () => goPage(currentPage + 1));
  paginationEl.querySelectorAll('[data-p]').forEach(b =>
    b.addEventListener('click', () => goPage(+b.dataset.p)));
}

function pageRange(cur, max) {
  if (max <= 7) return Array.from({length:max},(_,i)=>i+1);
  if (cur <= 4) return [1,2,3,4,5,'…',max];
  if (cur >= max-3) return [1,'…',max-4,max-3,max-2,max-1,max];
  return [1,'…',cur-1,cur,cur+1,'…',max];
}

function goPage(p) {
  const max = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  currentPage = Math.max(1, Math.min(p, max));
  renderPage();
  renderPagination();
  listEl.scrollIntoView({behavior:'smooth', block:'start'});
}

// ── Hint list (test panel) ────────────────────────────────────────────────────
function renderHints() {
  if (!hintList) return;

  if (!allShortcuts.length) {
    hintList.innerHTML =
      `<p style="font-size:12px;color:var(--text-light)">${i18n.t('hintNoShortcuts')}</p>`;
    return;
  }

  hintList.innerHTML = allShortcuts.slice(0, 10).map(sc => `
    <div class="hint-item">
      <span class="hint-trigger">${esc(sc.shortcut)}</span>
      <span class="hint-preview">${esc(sc.text.substring(0,30))}${sc.text.length>30?'…':''}</span>
    </div>
  `).join('');
}
// ── Test area: expand shortcuts inline ───────────────────────────────────────
testArea.addEventListener('input', () => {
  if (!allShortcuts.length) return;
  const pos    = testArea.selectionStart;
  const before = testArea.value.substring(0, pos);
  for (const sc of allShortcuts) {
    if (!sc.uses) sc.uses = 0;    if (!sc.shortcut || !sc.text) continue;
    if (before.endsWith(sc.shortcut)) {
      const after  = testArea.value.substring(pos);
      const expanded = sc.text;
      const newVal = before.slice(0, -sc.shortcut.length) + expanded + after;
      sc.uses = (sc.uses || 0) + 1;
      persist();
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      if (setter) setter.call(testArea, newVal);
      else testArea.value = newVal;
      const newPos = pos - sc.shortcut.length + sc.text.length;
      testArea.setSelectionRange(newPos, newPos);
      return;
    }
  }
});

btnClearTest.addEventListener('click', () => {
  testArea.value = '';
  testArea.focus();
});

// ── CRUD ──────────────────────────────────────────────────────────────────────
btnNew.addEventListener('click', () => {
  editingId = null;
  modalTitle.textContent = i18n.t('modalNewShortcut');
  inputShortcut.value       = '';
  inputText.value           = '';
  $('inputCategory').value  = '';
  populateCategorySelect();
  charCount.textContent = '0';
  openModal(modalOverlay);
  setTimeout(() => inputShortcut.focus(), 80);
});

function openEdit(id) {
  const sc = allShortcuts.find(s => String(s.id) === String(id));
  if (!sc) return;
  editingId = id;
  modalTitle.textContent  = i18n.t('modalEditShortcut');
  inputShortcut.value       = sc.shortcut;
  inputText.value           = sc.text;
  $('inputCategory').value  = sc.category || 'General';
  populateCategorySelect();
  charCount.textContent   = sc.text.length;
  openModal(modalOverlay);
  setTimeout(() => inputShortcut.focus(), 80);
}

inputText.addEventListener('input', () => {
  charCount.textContent = inputText.value.length;
});

btnSaveModal.addEventListener('click', saveShortcut);
inputShortcut.addEventListener('keydown', e => { if (e.key==='Enter') saveShortcut(); });

function saveShortcut() {
  const shortcut = inputShortcut.value.trim();
  const text     = inputText.value.trim();
  const category = ($('inputCategory').value.trim() || 'General').replace(/\b\w/g, l => l.toUpperCase());

  if (!shortcut) { shake(inputShortcut); inputShortcut.focus(); return; }
  if (!text)     { shake(inputText);     inputText.focus();     return; }

  const dup = allShortcuts.find(sc => sc.shortcut === shortcut && String(sc.id) !== String(editingId));
  if (dup) { showToast(i18n.t('toastShortcutExists', { name: shortcut })); shake(inputShortcut); return; }

  if (editingId !== null) {
    const idx = allShortcuts.findIndex(sc => String(sc.id) === String(editingId));
    if (idx !== -1) allShortcuts[idx] = { ...allShortcuts[idx], shortcut, text, category };
  } else {
    allShortcuts.push({ id: String(Date.now()), shortcut, text, category, uses: 0 });
  }

  persist(() => {
    closeModal(modalOverlay);
    showToast(editingId ? i18n.t('toastShortcutUpdated') : i18n.t('toastShortcutCreated'));
    editingId = null;
  });
}

function openDelete(id) {
  const sc = allShortcuts.find(s => String(s.id) === String(id));
  if (!sc) return;
  deleteId = id;
  deleteShortcutName.textContent = sc.shortcut;
  $('deleteWarningText').innerHTML = i18n.t('modalEliminarText', { name: `<strong>${esc(sc.shortcut)}</strong>` });
  openModal(deleteOverlay);
}

btnConfirmDelete.addEventListener('click', () => {
  allShortcuts = allShortcuts.filter(sc => String(sc.id) !== String(deleteId));
  persist(() => {
    closeModal(deleteOverlay);
    showToast(i18n.t('toastShortcutDeleted'));
    deleteId = null;
  });
});

// ── Persist (atómico: un ítem de storage por shortcut) ─────────────────────────
let lastKnownIds = new Set();

function persist(cb) {
  const currentIds = new Set(allShortcuts.map(sc => String(sc.id)));
  const dataToSave = {};
  allShortcuts.forEach(sc => { dataToSave[keyFor(sc.id)] = JSON.stringify(sc); });

  const keysToRemove = [...lastKnownIds]
    .filter(id => !currentIds.has(id))
    .map(id => keyFor(id));

  const finishWrite = () => {
    // Guardar en lotes de 20 para evitar truncamiento silencioso de chrome.storage.sync
    const entries = Object.entries(dataToSave);
    const BATCH_SIZE = 20;
    let i = 0;

    function writeBatch() {
      if (i >= entries.length) {
        lastKnownIds = currentIds;
        applyFilter();
        if (cb) cb();
        return;
      }
      const batch = Object.fromEntries(entries.slice(i, i + BATCH_SIZE));
      i += BATCH_SIZE;
      chrome.storage.sync.set(batch, () => {
        if (chrome.runtime.lastError) {
          showToast(i18n.t('toastStorageError', { error: chrome.runtime.lastError.message }));
          console.error("Storage Error:", chrome.runtime.lastError.message);
          return;
        }
        writeBatch();
      });
    }

    writeBatch();
  };

  if (keysToRemove.length > 0) {
    chrome.storage.sync.remove(keysToRemove, finishWrite);
  } else {
    finishWrite();
  }
}

// ── Delete All ────────────────────────────────────────────────────────────────
const btnDeleteAll = $('btnDeleteAll');

btnDeleteAll.addEventListener('click', () => {
  if (!allShortcuts.length) { showToast(i18n.t('toastNoShortcuts')); return; }
  $('deleteAllWarningText').innerHTML = i18n.t('deleteAll1Text', { count: `<strong>${allShortcuts.length}</strong>` });
  openModal($('deleteAllOverlay1'));
});

// Paso 1 — No / cerrar: no hace nada
$('btnDeleteAllNo1').addEventListener('click',    () => closeModal($('deleteAllOverlay1')));
$('btnCloseDeleteAll1').addEventListener('click', () => closeModal($('deleteAllOverlay1')));

// Paso 1 — Sí: ir al paso 2
$('btnDeleteAllSi1').addEventListener('click', () => {
  closeModal($('deleteAllOverlay1'));
  openModal($('deleteAllOverlay2'));
});

// Paso 2 — No / cerrar: no hace nada
$('btnDeleteAllNo2').addEventListener('click',    () => closeModal($('deleteAllOverlay2')));
$('btnCloseDeleteAll2').addEventListener('click', () => closeModal($('deleteAllOverlay2')));

// Paso 2 — Confirmar: descarga el backup y abre paso 3
$('btnDeleteAllConfirm').addEventListener('click', () => {
  const blob = new Blob(
    [JSON.stringify({ version: 1, shortcuts: allShortcuts }, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a   = Object.assign(document.createElement('a'), {
    href: url,
    download: `autotext-pro-backup-${stamp()}.json`
  });
  a.click();
  URL.revokeObjectURL(url);

  closeModal($('deleteAllOverlay2'));
$('inputDeleteConfirm').value = '';
  $('btnDeleteAllFinal').disabled = false;
  openModal($('deleteAllOverlay3'));
});

// Paso 3 — Enter confirma si la palabra es correcta
$('inputDeleteConfirm').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  if ($('inputDeleteConfirm').value === 'B0rr4r') $('btnDeleteAllFinal').click();
});

// Paso 3 — No / cerrar: no hace nada
$('btnDeleteAllNo3').addEventListener('click',    () => closeModal($('deleteAllOverlay3')));
$('btnCloseDeleteAll3').addEventListener('click', () => closeModal($('deleteAllOverlay3')));

// Paso 3 — Final: validar palabra y borrar todo
$('btnDeleteAllFinal').addEventListener('click', () => {
  if ($('inputDeleteConfirm').value !== 'B0rr4r') {
    showToast(i18n.t('toastWrongWord'));
    const overlay = $('deleteAllOverlay3');
    overlay.classList.remove('modal-shake');
    void overlay.offsetWidth;
    overlay.classList.add('modal-shake');
    setTimeout(() => overlay.classList.remove('modal-shake'), 500);
    return;
  }
  allShortcuts = [];
  persist(() => {
    closeModal($('deleteAllOverlay3'));
    showToast(i18n.t('toastAllDeleted'));
  });
});

// ── Export ────────────────────────────────────────────────────────────────────
btnExport.addEventListener('click', () => {
  const blob = new Blob(
    [JSON.stringify({ version: 1, shortcuts: allShortcuts, categories: allCategories }, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a   = Object.assign(document.createElement('a'), {
    href: url,
    download: `autotext-pro-${stamp()}.json`
  });
  a.click();
  URL.revokeObjectURL(url);
  showToast(i18n.t('toastExported', { count: allShortcuts.length }));
});

// ── Shortcut / para búsqueda ──────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === '/' && document.activeElement !== searchInput &&
      !document.activeElement.closest('.modal-overlay') &&
      !document.activeElement.closest('textarea') &&
      !document.activeElement.closest('input')) {
    e.preventDefault();
    searchInput.focus();
  }
  if (e.key === 'Escape') searchInput.blur();
});

// ── Sort & Filtros ────────────────────────────────────────────────────────────
let currentSort = 'created';
let showDupsOnly = false;

document.getElementById('btnShowDups').addEventListener('click', () => {
  showDupsOnly = true;
  document.getElementById('btnClearFilter').style.display = 'inline-flex';
  document.getElementById('btnShowDups').style.display = 'none';
  currentPage = 1;
  applyFilter();
});

document.getElementById('btnClearFilter').addEventListener('click', () => {
  showDupsOnly = false;
  document.getElementById('btnClearFilter').style.display = 'none';
  document.getElementById('btnShowDups').style.display = 'inline-flex';
  currentPage = 1;
  applyFilter();
});
document.addEventListener('click', e => {
  const btn = e.target.closest('.sort-btn');
  if (!btn) return;
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentSort = btn.dataset.sort;
  currentPage = 1;
  applyFilter();
});

// ── Import & Drag/Drop ────────────────────────────────────────────────────────
const dropZone = $('dropZone');

function processFile(file) {
  if (!file) return;
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['json','yaml','yml','xml','csv'].includes(ext)) {
    showToast(i18n.t('toastFormatsAccepted'));
    return;
  }

  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const txt = ev.target.result;
      let raw = [];

      if (ext === 'json') {
        const parsed = JSON.parse(txt);
        if (Array.isArray(parsed)) {
          raw = parsed;
        } else if (parsed.shortcuts && Array.isArray(parsed.shortcuts)) {
          raw = parsed.shortcuts;
          if (parsed.categories && Array.isArray(parsed.categories)) {
            parsed.categories.forEach(c => {
              if (!allCategories.some(e => e.name.toLowerCase() === c.name.toLowerCase())) {
                allCategories.push(c);
              }
            });
          }
          // Auto-crear categorías desde el campo category de cada shortcut
          raw.forEach(sc => {
            const cat = sc.category;
            if (cat && cat !== 'General' && !allCategories.some(e => e.name.toLowerCase() === cat.toLowerCase())) {
              allCategories.push({ name: cat, desc: '' });
            }
          });
          allCategories.sort((a, b) => a.name === 'General' ? -1 : b.name === 'General' ? 1 : a.name.localeCompare(b.name));
          saveCategories();
          renderCategories();
        } else if (typeof parsed === 'object' && parsed !== null) {
          const values = Object.values(parsed);
          if (values.length && typeof values[0] === 'object' && values[0].trigger) {
            raw = values.map(e => ({ shortcut: e.trigger, text: e.body }));
          } else {
            raw = Object.entries(parsed).map(([key, val]) => ({ shortcut: key, text: String(val) }));
          }
        }
      }

      else if (ext === 'yaml' || ext === 'yml') {
        const matches = [...txt.matchAll(/- trigger:\s*['"]?(.+?)['"]?\s*\n\s+replace:\s*([\s\S]*?)(?=\n- trigger:|\n*$)/gm)];
        raw = matches.map(m => ({ shortcut: m[1].trim(), text: m[2].trim() }));
      }

      else if (ext === 'xml') {
        const doc = new DOMParser().parseFromString(txt, 'text/xml');
        doc.querySelectorAll('snippet').forEach(n => {
          const shortcut = n.querySelector('abbreviation')?.textContent?.trim();
          const text     = n.querySelector('string')?.textContent?.trim();
          if (shortcut && text) raw.push({ shortcut, text });
        });
        if (!raw.length) {
          doc.querySelectorAll('phrase').forEach(n => {
            const shortcut = n.querySelector('trigger')?.textContent?.trim();
            const text     = n.querySelector('insert')?.textContent?.trim();
            if (shortcut && text) raw.push({ shortcut, text });
          });
        }
      }

      else if (ext === 'csv') {
        const lines = txt.split('\n').map(l => l.trim()).filter(Boolean);
        const start = lines[0]?.toLowerCase().startsWith('shortcut') ? 1 : 0;
        lines.slice(start).forEach(line => {
          const comma = line.indexOf(',');
          if (comma === -1) return;
          const shortcut = line.slice(0, comma).trim().replace(/^"|"$/g, '');
          const text     = line.slice(comma + 1).trim().replace(/^"|"$/g, '');
          if (shortcut && text) raw.push({ shortcut, text });
        });
      }

      const valid = raw.filter(sc => sc.shortcut && sc.text).map(sc => ({
        id: String(Date.now() + Math.random()),
        shortcut: String(sc.shortcut).trim(),
        text: String(sc.text),
        category: sc.category || 'General',
        uses: sc.uses || 0,
      }));

      if (!valid.length) throw new Error(i18n.t('toastNoValidShortcuts'));

      const duplicates = valid.filter(imp => allShortcuts.some(s => s.shortcut === imp.shortcut));
      const newOnes    = valid.filter(imp => !allShortcuts.some(s => s.shortcut === imp.shortcut));

      if (duplicates.length > 0) {
        const dupOverlay  = $('dupOverlay');
        const dupMessage  = $('dupMessage');
        dupMessage.textContent = duplicates.length === 1
          ? i18n.t('dupMsgSingle', { name: duplicates[0].shortcut })
          : i18n.t('dupMsgMultiple', { count: duplicates.length });
        openModal(dupOverlay);

        const cleanup = () => {
          $('btnDupOverwrite').onclick = null;
          $('btnDupRename').onclick    = null;
          $('btnDupCancel').onclick    = null;
          $('btnCloseDup').onclick     = null;
          closeModal(dupOverlay);
        };

        $('btnDupOverwrite').onclick = () => {
          cleanup();
          newOnes.forEach(imp => allShortcuts.push(imp));
          duplicates.forEach(imp => {
            const idx = allShortcuts.findIndex(s => s.shortcut === imp.shortcut);
            if (idx !== -1) allShortcuts[idx] = Object.assign(allShortcuts[idx], imp);
          });
          persist(() => {
            const msg = [newOnes.length && `${newOnes.length} ${i18n.t('toastNew')}`, duplicates.length && `${duplicates.length} ${i18n.t('toastOverwritten')}`].filter(Boolean).join(', ');
            showToast(i18n.t('toastImported', { msg }));
          });
        };

        $('btnDupRename').onclick = () => {
          cleanup();
          newOnes.forEach(imp => allShortcuts.push(imp));
          duplicates.forEach(imp => {
            let base = imp.shortcut, n = 2, candidate = `${base[0]}${n}${base.slice(1)}`;
            while (allShortcuts.some(s => s.shortcut === candidate)) { n++; candidate = `${base[0]}${n}${base.slice(1)}`; }
            allShortcuts.push({ ...imp, shortcut: candidate, id: String(Date.now() + Math.random()) });
          });
          persist(() => {
            const msg = [newOnes.length && `${newOnes.length} ${i18n.t('toastNew')}`, duplicates.length && `${duplicates.length} ${i18n.t('toastRenamed')}`].filter(Boolean).join(', ');
            showToast(i18n.t('toastImported', { msg }));
          });
        };

        $('btnDupCancel').onclick = () => { cleanup(); newOnes.forEach(imp => allShortcuts.push(imp)); persist(() => showToast(i18n.t('toastImportedAddedSkipped', { added: newOnes.length, skipped: duplicates.length }))); };
        $('btnCloseDup').onclick  = () => { cleanup(); };
        return;
      }

      let added = 0, updated = 0;
      valid.forEach(imp => {
        const idx = allShortcuts.findIndex(s => s.shortcut === imp.shortcut);
        if (idx !== -1) { allShortcuts[idx] = Object.assign(allShortcuts[idx], imp); updated++; }
        else { allShortcuts.push(imp); added++; }
      });

      persist(() => {
        const msg = [added && `${added} ${i18n.t('toastNew')}`, updated && `${updated} ${i18n.t('toastUpdated')}`].filter(Boolean).join(', ');
        showToast(i18n.t('toastImported', { msg }));
      });
    } catch (err) {
      showToast(i18n.t('toastImportError', { error: err.message }));
    }
    fileInput.value = '';
  };
  reader.readAsText(file);
}

// Eventos de botones
btnImport.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => processFile(e.target.files[0]));

// Eventos de Drag & Drop
document.addEventListener('dragenter', e => {
  if (e.dataTransfer?.types?.includes('Files')) dropZone.style.display = 'flex';
});

document.addEventListener('dragover', e => {
  e.preventDefault();
  dropZone.classList.add('over');
});

document.addEventListener('dragleave', e => {
  if (e.relatedTarget === null || e.relatedTarget === document.documentElement) {
    dropZone.style.display = 'none';
    dropZone.classList.remove('over');
  }
});

document.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.style.display = 'none';
  dropZone.classList.remove('over');
  processFile(e.dataTransfer?.files?.[0]);
});

// ── Privacy Policy ────────────────────────────────────────────────────────────
$('btnPrivacy').addEventListener('click',        () => openModal($('privacyOverlay')));
$('btnClosePrivacy').addEventListener('click',   () => closeModal($('privacyOverlay')));
$('btnClosePrivacy2').addEventListener('click',  () => closeModal($('privacyOverlay')));

// ── Tutorial ──────────────────────────────────────────────────────────────────
$('btnTutorial').addEventListener('click', () => openModal($('tutorialOverlay')));
$('btnCloseTutorial').addEventListener('click',  () => closeModal($('tutorialOverlay')));
$('btnCloseTutorial2').addEventListener('click', () => closeModal($('tutorialOverlay')));

// ── Dark mode (PENDIENTE: desactivado temporalmente) ──────────────────────────
// btnDark.addEventListener('click', () => {
//   const isDark = !document.body.classList.contains('dark');
//   applyDark(isDark);
//   chrome.storage.sync.set({ darkMode: isDark });
// });
// function applyDark(on) {
//   document.body.classList.toggle('dark', on);
//   const logo = document.querySelector('.brand-icon img');
//   if (logo) logo.src = on ? '../icons/logo-dark.png' : '../icons/logo-light.png';
//   btnDark.innerHTML = on
//     ? '<i class="fa-solid fa-sun"></i><span>Tema</span>'
//     : '<i class="fa-solid fa-moon"></i><span>Tema</span>';
// }

// ── Modal helpers ─────────────────────────────────────────────────────────────
function openModal(el)  { el.classList.add('open'); }
function closeModal(el) { el.classList.remove('open'); }

btnCancelModal.addEventListener('click',  () => closeModal(modalOverlay));
btnCloseModal.addEventListener('click',   () => closeModal(modalOverlay));
btnCancelDelete.addEventListener('click', () => closeModal(deleteOverlay));
btnCloseDelete.addEventListener('click',  () => closeModal(deleteOverlay));

[modalOverlay, deleteOverlay].forEach(o =>
  o.addEventListener('click', e => { if (e.target === o) closeModal(o); }));

// ── Utils ─────────────────────────────────────────────────────────────────────
let toastT;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => toast.classList.remove('show'), 2600);
}

function shake(el) {
  el.style.animation = 'none';
  el.getBoundingClientRect();
  el.style.animation = 'shake 0.3s ease';
  setTimeout(() => (el.style.animation = ''), 400);
}

function stamp() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
}
