// AutoText Pro — Diccionario de internacionalización (ES / EN / PT)
// Uso: i18n.t('clave') devuelve el string en el idioma activo.
// Uso con variables: i18n.t('clave', {nombre: valor}) reemplaza {{nombre}} en el string.

const I18N_DICT = {
  es: {
    // Header
    placeholderSearch: "Buscar por atajo o texto…",
    btnImport: "Importar",
    btnDeleteAll: "Borrar todo",
    btnExport: "Exportar",
    btnTutorial: "Tutorial",
    btnNewShortcut: "Nuevo shortcut",
    titleImport: "Importar JSON",
    titleDeleteAll: "Borrar todos los shortcuts",
    titleExport: "Exportar JSON",
    titleTutorial: "Tutorial",

    // Drop zone
    dropZoneText: "Suelta el archivo aquí",

    // Sidebar categorías
    categoriasTitle: "Categorías",
    titleNuevaCategoria: "Nueva categoría",

    // Stats / sort
    statsLabel: "shortcuts",
    statsHint: "Tip: Recuerda incluir un diferenciador <kbd>(! - . , *)</kbd> antes de cada palabra, así evitas que se expanda texto inesperado.",
    sortCreated: "Orden original",
    sortAZ: "A–Z",
    sortZA: "Z–A",
    sortUses: "Más usados",
    btnDups: "Duplicados",
    btnClearFilter: "Limpiar filtro",

    // Table header
    thShortcut: "Atajo",
    thText: "Texto expandido",
    thActions: "Acciones",

    // Empty state
    emptyTitle: "Oops! Aún nada por aquí",
    emptySub: 'No hay shortcuts aún. Creálos en la esquina superior derecha en el icono: <kbd> "+ Nuevo Shortcut"</kbd>',

    // Test panel
    testPanelTitle: "Probar shortcuts",
    testHint: "Usa este <kbd>recuadro</kbd> para <kbd>ensayar</kbd> en tiempo real tus atajos.",
    testPlaceholder: "Escribe aquí... prueba un atajo que ya tengas creado",
    btnClear: "Limpiar",

    // Footer
    footerPoweredBy: "Powered by",
    footerPrivacy: "Política de Privacidad",

    // Modal crear/editar
    modalNewShortcut: "Nuevo shortcut",
    modalEditShortcut: "Editar shortcut",
    labelAtajo: "Atajo",
    labelAtajoHint: "ej: .saludo",
    placeholderAtajo: ".miAtajo",
    labelCategoria: "Categoría",
    labelTextoExpandido: "Texto expandido",
    placeholderTexto: "El texto completo que aparecerá al usar el atajo…",
    charCountSuffix: "caracteres",
    btnCancelar: "Cancelar",
    btnGuardar: "Guardar",

    // Modal eliminar
    modalEliminarTitle: "Eliminar shortcut",
    modalEliminarText: "¿Eliminar {{name}}? Esta acción no se puede deshacer.",
    btnEliminar: "Eliminar",

    // Modal borrar todo - paso 1
    deleteAll1Title: "¿Borrar todos los shortcuts?",
    deleteAll1Text: "Esta acción eliminará {{count}} shortcuts. <strong>Primero debes guardar un respaldo.</strong> ¿Deseas continuar?",
    btnNoCancel: "No, cancelar",
    btnSiRespaldo: "Sí, hacer respaldo",

    // Modal borrar todo - paso 2
    deleteAll2Title: "Guardar respaldo obligatorio",
    deleteAll2Text: "Se descargará tu respaldo. <strong>Solo tras confirmar la descarga se borrarán los shortcuts.</strong> Si cerrás este aviso sin descargar, no se borrará nada.",
    btnDescargarBorrar: "Descargar respaldo y borrar",

    // Modal borrar todo - paso 3
    deleteAll3Title: "Confirmación final",
    deleteAll3Text: "Para confirmar la eliminación escribe exactamente: <kbd>B0rr4r</kbd>",
    placeholderB0rr4r: "Escribe B0rr4r aquí…",
    btnEliminarTodo: "Eliminar todo",

    // Privacy modal
    privacyTitle: "Política de Privacidad",
    privacyStep1Title: "Datos que guardamos",
    privacyStep1Text: "Los shortcuts y categorías que creás se guardan exclusivamente en <kbd>chrome.storage.sync</kbd> — el almacenamiento local de tu navegador. Nunca salen de tu dispositivo hacia ningún servidor externo.",
    privacyStep2Title: "Lo que NO hacemos",
    privacyStep2Text: "AutoText Pro no recopila, registra, ni transmite ningún dato personal, historial de navegación, ni el contenido de lo que escribís en las páginas web. La extensión solo detecta si escribiste un atajo tuyo para expandirlo.",
    privacyStep3Title: "Acceso a todas las páginas",
    privacyStep3Text: "La extensión solicita acceso a <kbd>&lt;all_urls&gt;</kbd> únicamente para poder detectar tus atajos en cualquier campo de texto de cualquier sitio web. No lee el contenido de las páginas, solo escucha lo que vos escribís en inputs y textareas.",
    privacyStep4Title: "Sincronización",
    privacyStep4Text: "Si tenés sesión iniciada en Chrome, tus shortcuts se sincronizan automáticamente entre tus dispositivos a través de <kbd>chrome.storage.sync</kbd> de Google. Este proceso es gestionado completamente por Google Chrome, no por nosotros.",
    privacyStep5Title: "Eliminación de datos",
    privacyStep5Text: "Podés eliminar todos tus datos en cualquier momento desde la extensión usando el botón <kbd>Borrar todo</kbd>, o desinstalando la extensión desde Chrome.",
    privacyStep6Title: "Contacto",
    privacyStep6Text: "Para cualquier consulta sobre privacidad o uso de datos, escribinos a <kbd>ceo.lemustudio@gmail.com</kbd> | También puedes reportar errores en ese mismo correo",
    privacyUpdated: "Última actualización: Junio 2026 · AutoText Pro by Lemu Studio",
    btnEntendido: "Entendido",

    // Tutorial modal
    tutorialTitle: "Tutorial — AutoText Pro",
    tut1Title: "1. Crear un shortcut",
    tut1Text: "Haz clic en <kbd>+ Nuevo shortcut</kbd>, escribe un atajo como <kbd>.hola</kbd> y el texto que quieres que aparezca. Guarda y listo.",
    tut2Title: "2. Usar el shortcut",
    tut2Text: "En cualquier campo de texto de cualquier página web, escribe tu atajo exacto (ej: <kbd>.hola</kbd>) y se expandirá automáticamente.",
    tut3Title: "3. Usa un diferenciador",
    tut3Text: "Siempre empieza tus atajos con <kbd>.</kbd> <kbd>,</kbd> <kbd>!</kbd> o <kbd>*</kbd> para evitar que se expandan palabras normales. Ej: <kbd>.firma</kbd> en vez de <kbd>firma</kbd>.",
    tut4Title: "4. Categorías",
    tut4Text: "Crea categorías desde el panel izquierdo con <kbd>+</kbd> para organizar tus shortcuts por tema: Trabajo, Emails, Soporte, etc.",
    tut5Title: "5. Importar y exportar",
    tut5Text: "Usa <kbd>Exportar</kbd> para hacer respaldo de tus shortcuts. Usa <kbd>Importar</kbd> para cargarlos en otro dispositivo o desde Espanso, TextExpander o PhraseExpress. Si deseas puede arrastrar y soltar en la pantalla tu respaldo<kbd>| Drag/Drop |</kbd> para cargar tus <kbd>shortcuts</kbd> más rápido y fácil",
    tut6Title: "6. Búsqueda rápida",
    tut6Text: "Presiona <kbd>/</kbd> desde cualquier parte para enfocar el buscador. Presiona <kbd>Esc</kbd> para salir.",
    tut7Title: "7. Más usados",
    tut7Text: "Cada vez que usás un shortcut, se registra internamente. Ordena por <kbd>Más usados</kbd> para ver cuáles son tus favoritos.",
    tut8Title: "8. Límite de almacenamiento",
    tut8Text: "Esta extensión es gratuita. Chrome permite aproximadamente <kbd>400–500 shortcuts</kbd> cortos. Exporta regularmente para no perder tu trabajo.",

    // Category modal
    catModalTitle: "Gestionar categorías",
    placeholderCatName: "Nombre de categoría…",
    btnCrear: "Crear",

    // Duplicates modal
    dupModalTitle: "Shortcuts duplicados",
    btnRenombrar: "Renombrar",
    btnSobreescribir: "Sobreescribir",
    dupMsgSingle: '"{{name}}" ya existe. ¿Qué deseas hacer?',
    dupMsgMultiple: "{{count}} shortcuts ya existen. ¿Qué deseas hacer?",
    btnEditar: "Editar",
    catTodos: "Todos",
    catGeneral: "General",
    hintNoShortcuts: "Sin shortcuts aún",

    // Toasts dinámicos
    toastCatExists: 'La categoría "{{name}}" ya existe',
    toastCatRenamed: 'Categoría renombrada a "{{name}}" ✓',
    toastCatCreated: 'Categoría "{{name}}" creada ✓',
    toastCatLimit: "Límite de 50 categorías alcanzado",
    toastShortcutExists: 'El atajo "{{name}}" ya existe',
    toastShortcutUpdated: "Shortcut actualizado ✓",
    toastShortcutCreated: "Shortcut creado ✓",
    toastShortcutDeleted: "Shortcut eliminado",
    toastStorageError: "Error al guardar: {{error}}",
    toastNoShortcuts: "No hay shortcuts para borrar",
    toastWrongWord: "Palabra incorrecta — escribe exactamente B0rr4r",
    toastAllDeleted: "Todos los shortcuts eliminados ✓",
    toastExported: "{{count}} shortcuts exportados ✓",
    toastFormatsAccepted: "Formatos aceptados: .json, .yaml, .yml, .xml, .csv",
    toastImported: "Importados: {{msg}} ✓",
    toastImportedAddedSkipped: "{{added}} nuevos agregados, {{skipped}} saltados ✓",
    toastImportError: "Error al importar: {{error}}",
    toastNoValidShortcuts: "Sin shortcuts válidos en el archivo",
    toastNew: "nuevos",
    toastUpdated: "actualizados",
    toastOverwritten: "sobreescritos",
    toastRenamed: "renombrados",
  },

  en: {
    placeholderSearch: "Search by shortcut or text…",
    btnImport: "Import",
    btnDeleteAll: "Delete all",
    btnExport: "Export",
    btnTutorial: "Tutorial",
    btnNewShortcut: "New shortcut",
    titleImport: "Import JSON",
    titleDeleteAll: "Delete all shortcuts",
    titleExport: "Export JSON",
    titleTutorial: "Tutorial",

    dropZoneText: "Drop the file here",

    categoriasTitle: "Categories",
    titleNuevaCategoria: "New category",

    statsLabel: "shortcuts",
    statsHint: "Tip: Remember to include a differentiator <kbd>(! - . , *)</kbd> before each word, this avoids unexpected text expansion.",
    sortCreated: "Original order",
    sortAZ: "A–Z",
    sortZA: "Z–A",
    sortUses: "Most used",
    btnDups: "Duplicates",
    btnClearFilter: "Clear filter",

    thShortcut: "Shortcut",
    thText: "Expanded text",
    thActions: "Actions",

    emptyTitle: "Oops! Nothing here yet",
    emptySub: 'No shortcuts yet. Create them in the top right icon: <kbd> "+ New Shortcut"</kbd>',

    testPanelTitle: "Test shortcuts",
    testHint: "Use this <kbd>box</kbd> to <kbd>try out</kbd> your shortcuts in real time.",
    testPlaceholder: "Type here... try a shortcut you've already created",
    btnClear: "Clear",

    footerPoweredBy: "Powered by",
    footerPrivacy: "Privacy Policy",

    modalNewShortcut: "New shortcut",
    modalEditShortcut: "Edit shortcut",
    labelAtajo: "Shortcut",
    labelAtajoHint: "e.g: .greeting",
    placeholderAtajo: ".myShortcut",
    labelCategoria: "Category",
    labelTextoExpandido: "Expanded text",
    placeholderTexto: "The full text that will appear when using the shortcut…",
    charCountSuffix: "characters",
    btnCancelar: "Cancel",
    btnGuardar: "Save",

    modalEliminarTitle: "Delete shortcut",
    modalEliminarText: "Delete {{name}}? This action cannot be undone.",
    btnEliminar: "Delete",

    deleteAll1Title: "Delete all shortcuts?",
    deleteAll1Text: "This action will delete {{count}} shortcuts. <strong>You must back up first.</strong> Do you want to continue?",
    btnNoCancel: "No, cancel",
    btnSiRespaldo: "Yes, back up",

    deleteAll2Title: "Mandatory backup",
    deleteAll2Text: "Your backup will be downloaded. <strong>Shortcuts will only be deleted after confirming the download.</strong> If you close this without downloading, nothing will be deleted.",
    btnDescargarBorrar: "Download backup and delete",

    deleteAll3Title: "Final confirmation",
    deleteAll3Text: "To confirm deletion type exactly: <kbd>B0rr4r</kbd>",
    placeholderB0rr4r: "Type B0rr4r here…",
    btnEliminarTodo: "Delete all",

    privacyTitle: "Privacy Policy",
    privacyStep1Title: "Data we store",
    privacyStep1Text: "The shortcuts and categories you create are stored exclusively in <kbd>chrome.storage.sync</kbd> — your browser's local storage. They never leave your device to any external server.",
    privacyStep2Title: "What we DON'T do",
    privacyStep2Text: "AutoText Pro does not collect, log, or transmit any personal data, browsing history, or the content of what you type on web pages. The extension only detects if you typed one of your own shortcuts to expand it.",
    privacyStep3Title: "Access to all pages",
    privacyStep3Text: "The extension requests access to <kbd>&lt;all_urls&gt;</kbd> solely to detect your shortcuts in any text field on any website. It does not read page content, it only listens to what you type in inputs and textareas.",
    privacyStep4Title: "Sync",
    privacyStep4Text: "If you're signed in to Chrome, your shortcuts sync automatically across your devices via Google's <kbd>chrome.storage.sync</kbd>. This process is fully managed by Google Chrome, not by us.",
    privacyStep5Title: "Data deletion",
    privacyStep5Text: "You can delete all your data at any time from the extension using the <kbd>Delete all</kbd> button, or by uninstalling the extension from Chrome.",
    privacyStep6Title: "Contact",
    privacyStep6Text: "For any questions about privacy or data use, write to us at <kbd>ceo.lemustudio@gmail.com</kbd> | You can also report bugs at the same email",
    privacyUpdated: "Last updated: June 2026 · AutoText Pro by Lemu Studio",
    btnEntendido: "Got it",

    tutorialTitle: "Tutorial — AutoText Pro",
    tut1Title: "1. Create a shortcut",
    tut1Text: "Click <kbd>+ New shortcut</kbd>, type a shortcut like <kbd>.hello</kbd> and the text you want to appear. Save and done.",
    tut2Title: "2. Use the shortcut",
    tut2Text: "In any text field on any web page, type your exact shortcut (e.g: <kbd>.hello</kbd>) and it will expand automatically.",
    tut3Title: "3. Use a differentiator",
    tut3Text: "Always start your shortcuts with <kbd>.</kbd> <kbd>,</kbd> <kbd>!</kbd> or <kbd>*</kbd> to avoid expanding normal words. E.g: <kbd>.signature</kbd> instead of <kbd>signature</kbd>.",
    tut4Title: "4. Categories",
    tut4Text: "Create categories from the left panel with <kbd>+</kbd> to organize your shortcuts by topic: Work, Emails, Support, etc.",
    tut5Title: "5. Import and export",
    tut5Text: "Use <kbd>Export</kbd> to back up your shortcuts. Use <kbd>Import</kbd> to load them on another device or from Espanso, TextExpander or PhraseExpress. You can also drag and drop your backup<kbd>| Drag/Drop |</kbd> onto the screen to load your <kbd>shortcuts</kbd> faster and easier",
    tut6Title: "6. Quick search",
    tut6Text: "Press <kbd>/</kbd> from anywhere to focus the search bar. Press <kbd>Esc</kbd> to exit.",
    tut7Title: "7. Most used",
    tut7Text: "Every time you use a shortcut, it's tracked internally. Sort by <kbd>Most used</kbd> to see your favorites.",
    tut8Title: "8. Storage limit",
    tut8Text: "This extension is free. Chrome allows approximately <kbd>400–500 short shortcuts</kbd>. Export regularly to avoid losing your work.",

    catModalTitle: "Manage categories",
    placeholderCatName: "Category name…",
    btnCrear: "Create",

    dupModalTitle: "Duplicate shortcuts",
    btnRenombrar: "Rename",
    btnSobreescribir: "Overwrite",
    dupMsgSingle: '"{{name}}" already exists. What do you want to do?',
    dupMsgMultiple: "{{count}} shortcuts already exist. What do you want to do?",
    btnEditar: "Edit",
    catTodos: "All",
    catGeneral: "General",
    hintNoShortcuts: "No shortcuts yet",

    toastCatExists: 'Category "{{name}}" already exists',
    toastCatRenamed: 'Category renamed to "{{name}}" ✓',
    toastCatCreated: 'Category "{{name}}" created ✓',
    toastCatLimit: "Limit of 50 categories reached",
    toastShortcutExists: 'Shortcut "{{name}}" already exists',
    toastShortcutUpdated: "Shortcut updated ✓",
    toastShortcutCreated: "Shortcut created ✓",
    toastShortcutDeleted: "Shortcut deleted",
    toastStorageError: "Error saving: {{error}}",
    toastNoShortcuts: "No shortcuts to delete",
    toastWrongWord: "Wrong word — type exactly B0rr4r",
    toastAllDeleted: "All shortcuts deleted ✓",
    toastExported: "{{count}} shortcuts exported ✓",
    toastFormatsAccepted: "Accepted formats: .json, .yaml, .yml, .xml, .csv",
    toastImported: "Imported: {{msg}} ✓",
    toastImportedAddedSkipped: "{{added}} new added, {{skipped}} skipped ✓",
    toastImportError: "Import error: {{error}}",
    toastNoValidShortcuts: "No valid shortcuts in the file",
    toastNew: "new",
    toastUpdated: "updated",
    toastOverwritten: "overwritten",
    toastRenamed: "renamed",
  },

  pt: {
    placeholderSearch: "Buscar por atalho ou texto…",
    btnImport: "Importar",
    btnDeleteAll: "Excluir tudo",
    btnExport: "Exportar",
    btnTutorial: "Tutorial",
    btnNewShortcut: "Novo atalho",
    titleImport: "Importar JSON",
    titleDeleteAll: "Excluir todos os atalhos",
    titleExport: "Exportar JSON",
    titleTutorial: "Tutorial",

    dropZoneText: "Solte o arquivo aqui",

    categoriasTitle: "Categorias",
    titleNuevaCategoria: "Nova categoria",

    statsLabel: "atalhos",
    statsHint: "Dica: Lembre-se de incluir um diferenciador <kbd>(! - . , *)</kbd> antes de cada palavra, isso evita expansão de texto inesperada.",
    sortCreated: "Ordem original",
    sortAZ: "A–Z",
    sortZA: "Z–A",
    sortUses: "Mais usados",
    btnDups: "Duplicados",
    btnClearFilter: "Limpar filtro",

    thShortcut: "Atalho",
    thText: "Texto expandido",
    thActions: "Ações",

    emptyTitle: "Ops! Ainda nada por aqui",
    emptySub: 'Ainda não há atalhos. Crie-os no ícone superior direito: <kbd> "+ Novo Atalho"</kbd>',

    testPanelTitle: "Testar atalhos",
    testHint: "Use esta <kbd>caixa</kbd> para <kbd>testar</kbd> seus atalhos em tempo real.",
    testPlaceholder: "Digite aqui... teste um atalho que você já criou",
    btnClear: "Limpar",

    footerPoweredBy: "Desenvolvido por",
    footerPrivacy: "Política de Privacidade",

    modalNewShortcut: "Novo atalho",
    modalEditShortcut: "Editar atalho",
    labelAtajo: "Atalho",
    labelAtajoHint: "ex: .saudacao",
    placeholderAtajo: ".meuAtalho",
    labelCategoria: "Categoria",
    labelTextoExpandido: "Texto expandido",
    placeholderTexto: "O texto completo que aparecerá ao usar o atalho…",
    charCountSuffix: "caracteres",
    btnCancelar: "Cancelar",
    btnGuardar: "Salvar",

    modalEliminarTitle: "Excluir atalho",
    modalEliminarText: "Excluir {{name}}? Esta ação não pode ser desfeita.",
    btnEliminar: "Excluir",

    deleteAll1Title: "Excluir todos os atalhos?",
    deleteAll1Text: "Esta ação excluirá {{count}} atalhos. <strong>Primeiro você deve fazer um backup.</strong> Deseja continuar?",
    btnNoCancel: "Não, cancelar",
    btnSiRespaldo: "Sim, fazer backup",

    deleteAll2Title: "Backup obrigatório",
    deleteAll2Text: "Seu backup será baixado. <strong>Os atalhos só serão excluídos após confirmar o download.</strong> Se você fechar este aviso sem baixar, nada será excluído.",
    btnDescargarBorrar: "Baixar backup e excluir",

    deleteAll3Title: "Confirmação final",
    deleteAll3Text: "Para confirmar a exclusão, digite exatamente: <kbd>B0rr4r</kbd>",
    placeholderB0rr4r: "Digite B0rr4r aqui…",
    btnEliminarTodo: "Excluir tudo",

    privacyTitle: "Política de Privacidade",
    privacyStep1Title: "Dados que armazenamos",
    privacyStep1Text: "Os atalhos e categorias que você cria são armazenados exclusivamente em <kbd>chrome.storage.sync</kbd> — o armazenamento local do seu navegador. Eles nunca saem do seu dispositivo para nenhum servidor externo.",
    privacyStep2Title: "O que NÃO fazemos",
    privacyStep2Text: "O AutoText Pro não coleta, registra nem transmite dados pessoais, histórico de navegação, ou o conteúdo do que você digita nas páginas web. A extensão apenas detecta se você digitou um dos seus atalhos para expandi-lo.",
    privacyStep3Title: "Acesso a todas as páginas",
    privacyStep3Text: "A extensão solicita acesso a <kbd>&lt;all_urls&gt;</kbd> apenas para detectar seus atalhos em qualquer campo de texto de qualquer site. Ela não lê o conteúdo das páginas, apenas escuta o que você digita em inputs e textareas.",
    privacyStep4Title: "Sincronização",
    privacyStep4Text: "Se você estiver conectado ao Chrome, seus atalhos são sincronizados automaticamente entre seus dispositivos via <kbd>chrome.storage.sync</kbd> do Google. Esse processo é gerenciado totalmente pelo Google Chrome, não por nós.",
    privacyStep5Title: "Exclusão de dados",
    privacyStep5Text: "Você pode excluir todos os seus dados a qualquer momento na extensão usando o botão <kbd>Excluir tudo</kbd>, ou desinstalando a extensão do Chrome.",
    privacyStep6Title: "Contato",
    privacyStep6Text: "Para qualquer dúvida sobre privacidade ou uso de dados, escreva para <kbd>ceo.lemustudio@gmail.com</kbd> | Você também pode reportar erros no mesmo e-mail",
    privacyUpdated: "Última atualização: junho de 2026 · AutoText Pro by Lemu Studio",
    btnEntendido: "Entendi",

    tutorialTitle: "Tutorial — AutoText Pro",
    tut1Title: "1. Criar um atalho",
    tut1Text: "Clique em <kbd>+ Novo atalho</kbd>, digite um atalho como <kbd>.oi</kbd> e o texto que deseja que apareça. Salve e pronto.",
    tut2Title: "2. Usar o atalho",
    tut2Text: "Em qualquer campo de texto de qualquer página web, digite seu atalho exato (ex: <kbd>.oi</kbd>) e ele se expandirá automaticamente.",
    tut3Title: "3. Use um diferenciador",
    tut3Text: "Sempre comece seus atalhos com <kbd>.</kbd> <kbd>,</kbd> <kbd>!</kbd> ou <kbd>*</kbd> para evitar expandir palavras normais. Ex: <kbd>.assinatura</kbd> em vez de <kbd>assinatura</kbd>.",
    tut4Title: "4. Categorias",
    tut4Text: "Crie categorias no painel esquerdo com <kbd>+</kbd> para organizar seus atalhos por tema: Trabalho, E-mails, Suporte, etc.",
    tut5Title: "5. Importar e exportar",
    tut5Text: "Use <kbd>Exportar</kbd> para fazer backup dos seus atalhos. Use <kbd>Importar</kbd> para carregá-los em outro dispositivo ou do Espanso, TextExpander ou PhraseExpress. Se desejar, arraste e solte seu backup<kbd>| Drag/Drop |</kbd> na tela para carregar seus <kbd>atalhos</kbd> mais rápido e fácil",
    tut6Title: "6. Busca rápida",
    tut6Text: "Pressione <kbd>/</kbd> de qualquer lugar para focar a busca. Pressione <kbd>Esc</kbd> para saber.",
    tut7Title: "7. Mais usados",
    tut7Text: "Cada vez que você usa um atalho, isso é registrado internamente. Ordene por <kbd>Mais usados</kbd> para ver seus favoritos.",
    tut8Title: "8. Limite de armazenamento",
    tut8Text: "Esta extensão é gratuita. O Chrome permite aproximadamente <kbd>400–500 atalhos</kbd> curtos. Exporte regularmente para não perder seu trabalho.",

    catModalTitle: "Gerenciar categorias",
    placeholderCatName: "Nome da categoria…",
    btnCrear: "Criar",

    dupModalTitle: "Atalhos duplicados",
    btnRenombrar: "Renomear",
    btnSobreescribir: "Sobrescrever",
    dupMsgSingle: '"{{name}}" já existe. O que você quer fazer?',
    dupMsgMultiple: "{{count}} atalhos já existem. O que você quer fazer?",
    btnEditar: "Editar",
    catTodos: "Todos",
    catGeneral: "Geral",
    hintNoShortcuts: "Ainda sem atalhos",
    toastCatExists: 'A categoria "{{name}}" já existe',
    toastCatRenamed: 'Categoria renomeada para "{{name}}" ✓',
    toastCatCreated: 'Categoria "{{name}}" criada ✓',
    toastCatLimit: "Limite de 50 categorias atingido",
    toastShortcutExists: 'O atalho "{{name}}" já existe',
    toastShortcutUpdated: "Atalho atualizado ✓",
    toastShortcutCreated: "Atalho criado ✓",
    toastShortcutDeleted: "Atalho excluído",
    toastStorageError: "Erro ao salvar: {{error}}",
    toastNoShortcuts: "Não há atalhos para excluir",
    toastWrongWord: "Palavra incorreta — digite exatamente B0rr4r",
    toastAllDeleted: "Todos os atalhos excluídos ✓",
    toastExported: "{{count}} atalhos exportados ✓",
    toastFormatsAccepted: "Formatos aceitos: .json, .yaml, .yml, .xml, .csv",
    toastImported: "Importados: {{msg}} ✓",
    toastImportedAddedSkipped: "{{added}} novos adicionados, {{skipped}} ignorados ✓",
    toastImportError: "Erro ao importar: {{error}}",
    toastNoValidShortcuts: "Nenhum atalho válido no arquivo",
    toastNew: "novos",
    toastUpdated: "atualizados",
    toastOverwritten: "sobrescritos",
    toastRenamed: "renomeados",
  }
};

const i18n = {
  current: 'es',

  init(cb) {
    chrome.storage.sync.get(['language'], (r) => {
      this.current = r.language || this.detectBrowserLang();
      if (cb) cb();
    });
  },

  detectBrowserLang() {
    const lang = (navigator.language || 'es').slice(0, 2).toLowerCase();
    return I18N_DICT[lang] ? lang : 'es';
  },

  setLanguage(lang, cb) {
    if (!I18N_DICT[lang]) return;
    this.current = lang;
    chrome.storage.sync.set({ language: lang }, () => { if (cb) cb(); });
  },

  t(key, vars) {
    let str = (I18N_DICT[this.current] && I18N_DICT[this.current][key]) || I18N_DICT.es[key] || key;
    if (vars) {
      Object.keys(vars).forEach(k => {
        str = str.replace(new RegExp('{{' + k + '}}', 'g'), vars[k]);
      });
    }
    return str;
  }
};
